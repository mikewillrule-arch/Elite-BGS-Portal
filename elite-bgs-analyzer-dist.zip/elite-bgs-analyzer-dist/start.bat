@echo off
title Ken'Tarii Mandate Intelligence Dashboard
color 0B
echo.
echo  ============================================
echo   Ken'Tarii Mandate Intelligence Dashboard
echo  ============================================
echo.

cd /d "%~dp0"

REM Check Node.js is installed
where node >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Node.js not found. Install from https://nodejs.org
  pause
  exit /b 1
)

REM Check .env exists
if not exist "%~dp0.env" (
  echo [ERROR] .env file not found. Run setup.bat first.
  pause
  exit /b 1
)

REM Kill any existing node/ngrok processes
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":3000 " 2^>nul') do (
  taskkill /F /PID %%a >nul 2>&1
)
taskkill /F /IM ngrok.exe >nul 2>&1

echo [1/2] Starting Node.js server on port 3000...
start /B node "%~dp0server.js" > "%~dp0server.log" 2>&1
timeout /t 3 /nobreak > nul
echo       Server running. Log saved to server.log
echo.

REM ── ngrok permanent tunnel ────────────────────────────────────────────────────
echo [2/2] Starting ngrok tunnel...
echo.
echo  ================================================================
echo   SQUADRON URL (permanent - share this with your whole squadron):
echo   https://nonskeletal-davin-nonzonated.ngrok-free.dev
echo  ================================================================
echo.
echo  Also accessible locally at: http://localhost:3000
echo  (Keep this window open while the dashboard is running)
echo.
ngrok http --domain=nonskeletal-davin-nonzonated.ngrok-free.dev 3000

echo.
echo [Dashboard stopped]
pause
