#!/usr/bin/env node
require('dotenv').config();

const express  = require('express');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const Groq     = require('groq-sdk');
const https    = require('https');
const http     = require('http');
const path     = require('path');
const fs = require('fs');
const crypto   = require('crypto');
const WebSocket = require('ws');
const EDDNListener = require('./eddn-listener');
const Inara    = require('./inara');

if (!process.env.GEMINI_API_KEY && !process.env.GROQ_API_KEY) {
  console.error('At least one AI key required: GEMINI_API_KEY or GROQ_API_KEY in .env');
  process.exit(1);
}

const INARA_KEY      = process.env.INARA_API_KEY   || null;
const DEFAULT_SQUAD  = process.env.DEFAULT_SQUADRON || "The Ken'Tarii Mandate";
const PORT           = parseInt(process.env.PORT)   || 3000;
const LEADERSHIP_KEY = process.env.LEADERSHIP_KEY  || 'THKI2112';
const DEV_KEY        = process.env.DEV_KEY         || 'L1vewire!';

// ─── Lockdown state ───────────────────────────────────────────────────────────
let lockdownActive = false;

// ─── Feature data files ───────────────────────────────────────────────────────
const TICK_HISTORY_FILE  = path.join(__dirname, 'data', 'tick_history.json');
const ANNOTATIONS_FILE   = path.join(__dirname, 'data', 'map_annotations.json');
const RIVAL_FILE         = path.join(__dirname, 'data', 'rival_config.json');
const USERS_FILE         = path.join(__dirname, 'data', 'users.json');
const AI_STATE_FILE      = path.join(__dirname, 'data', 'ai_state.json');
const DEV_ACTIVITY_FILE  = path.join(__dirname, 'data', 'dev_activity_log.json');
const SETUP_FILE         = path.join(__dirname, 'data', 'squadron_config.json');

// ─── Feature state ────────────────────────────────────────────────────────────
let tickHistory   = [];
let mapAnnotations = [];
let rivalConfig   = { faction: null, lastFetch: 0, data: null };
let usersDb       = {};
let devActivityLog = [];

function deriveInitials(name) {
  return (name || '')
    .split(/\s+/)
    .filter(w => w.length > 2)  // skip "The", "of", etc.
    .map(w => w[0].toUpperCase())
    .slice(0, 3)
    .join('');
}

// ─── Squadron config ──────────────────────────────────────────────────────────
let squadronConfig = {
  setupComplete: false,
  squadronName: '',
  initials: '',
  primaryColor: '#00d4ff',
  accentColor: '#00ff88',
  highlightColor: '#ff8800',
  inaraSquadronName: '',
};

function loadSquadronConfig() {
  try {
    if (fs.existsSync(SETUP_FILE))
      squadronConfig = { ...squadronConfig, ...JSON.parse(fs.readFileSync(SETUP_FILE, 'utf8')) };
  } catch (e) { console.warn('  [config] Load failed:', e.message); }
}
loadSquadronConfig();

function saveSquadronConfig() {
  try { fs.writeFileSync(SETUP_FILE, JSON.stringify(squadronConfig, null, 2)); }
  catch (e) { console.warn('  [config] Save failed:', e.message); }
}

function _loadDevActivityLog() {
  try {
    if (fs.existsSync(DEV_ACTIVITY_FILE))
      devActivityLog = JSON.parse(fs.readFileSync(DEV_ACTIVITY_FILE, 'utf8'));
  } catch (e) { console.warn('  [dev-activity] Load failed:', e.message); }
}
_loadDevActivityLog();

function _saveDevActivityLog() {
  try { fs.writeFileSync(DEV_ACTIVITY_FILE, JSON.stringify(devActivityLog)); }
  catch (e) { console.warn('  [dev-activity] Save failed:', e.message); }
}

const genAI            = process.env.GEMINI_API_KEY ? new GoogleGenerativeAI(process.env.GEMINI_API_KEY) : null;
const GROQ_KEY         = process.env.GROQ_API_KEY || null;
const groqClient       = GROQ_KEY ? new Groq({ apiKey: GROQ_KEY }) : null;
const GROQ_MODEL       = 'llama-3.3-70b-versatile';
const OPENROUTER_KEY   = process.env.OPENROUTER_API_KEY || null;
const OPENROUTER_MODEL = 'meta-llama/llama-3.3-70b-instruct:free';
const MISTRAL_KEY      = process.env.MISTRAL_API_KEY || null;
const MISTRAL_MODEL    = 'ministral-8b-latest';
const app   = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ─── EDDN listener ────────────────────────────────────────────────────────────
loadSquadronConfig();  // ensure config loaded before EDDN starts
const eddn = new EDDNListener(squadronConfig.squadronName || DEFAULT_SQUAD);
eddn.start().catch(e => console.error('[EDDN] Fatal:', e.message));

// SSE clients
const sseClients = new Set();
function broadcast(payload) {
  const msg = `data: ${JSON.stringify(payload)}\n\n`;
  for (const res of sseClients) { try { res.write(msg); } catch {} }
}

eddn.on('event',     ev    => broadcast({ type: 'event',     event: ev }));
eddn.on('heartbeat', stats => broadcast({ type: 'heartbeat', stats }));
eddn.on('connected', ()    => broadcast({ type: 'connected' }));
eddn.on('diag',      entry => broadcast({ type: 'diag',      entry }));
eddn.on('seeded',    list  => broadcast({ type: 'seeded',    systems: list }));
eddn.on('tick',      info  => {
  broadcast({ type: 'tick', info });
  recordTick(info.time);
  onTickDetected(info).catch(e => console.warn('  [tick-monitor] Error:', e.message));
});
eddn.on('rawbeat',   data  => broadcast({ type: 'rawbeat',   data }));

// ─── Tick detection gate — prevents double-firing from two sources ────────────
let _lastTickFiredAt = 0;

async function onTickDetected(info) {
  const now = Date.now();
  if (now - _lastTickFiredAt < 12 * 3_600_000) return;  // suppress within 12h
  _lastTickFiredAt = now;
  await startPostTickMonitor();
}

// ─── tick.edcd.io — secondary tick detector ───────────────────────────────────
// Polls the REST API every 5 min and connects via WebSocket for real-time push.
// Whichever source (EDDN or edcd.io) fires first wins; the gate above prevents doubles.

let _edcdLastTick = null;   // last tick ISO string seen from edcd.io

function _pollEdcdTick() {
  const req = https.get('https://tick.edcd.io/', {
    headers: { 'User-Agent': 'KenTariiMandateBGS/1.0', Accept: 'application/json' },
    timeout: 10000,
  }, res => {
    let buf = '';
    res.on('data', d => (buf += d));
    res.on('end', () => {
      try {
        const data = JSON.parse(buf);
        // API returns { lastUpdated: "ISO string", ... }
        const tickIso = data.lastUpdated || data.time || data.tick || null;
        if (!tickIso) return;
        if (_edcdLastTick && tickIso !== _edcdLastTick) {
          console.log(`  [tick.edcd.io] New tick confirmed: ${tickIso}`);
          _edcdLastTick = tickIso;
          recordTick(tickIso);
          onTickDetected({ time: tickIso, source: 'edcd.io', systems: [] })
            .catch(e => console.warn('  [tick-monitor] edcd.io trigger error:', e.message));
          broadcast({ type: 'tick', info: { time: tickIso, source: 'edcd.io', systems: [] } });
        } else if (!_edcdLastTick) {
          _edcdLastTick = tickIso;
          console.log(`  [tick.edcd.io] Baseline tick: ${tickIso}`);
        }
      } catch {}
    });
  });
  req.on('error', () => {});  // silently ignore — EDDN is primary
  req.on('timeout', () => req.destroy());
}

function _connectEdcdWebSocket() {
  try {
    const ws = new WebSocket('wss://tick.edcd.io/ws');
    ws.on('open',  ()  => console.log('  [tick.edcd.io] WebSocket connected.'));
    ws.on('message', raw => {
      try {
        const data = JSON.parse(raw);
        const tickIso = data.lastUpdated || data.time || data.tick || null;
        if (!tickIso || tickIso === _edcdLastTick) return;
        console.log(`  [tick.edcd.io] WebSocket tick push: ${tickIso}`);
        _edcdLastTick = tickIso;
        recordTick(tickIso);
        onTickDetected({ time: tickIso, source: 'edcd.io-ws', systems: [] })
          .catch(e => console.warn('  [tick-monitor] WS trigger error:', e.message));
        broadcast({ type: 'tick', info: { time: tickIso, source: 'edcd.io-ws', systems: [] } });
      } catch {}
    });
    ws.on('error', () => {});
    ws.on('close', () => {
      console.log('  [tick.edcd.io] WebSocket disconnected — reconnecting in 60s...');
      setTimeout(_connectEdcdWebSocket, 60_000);
    });
  } catch {
    setTimeout(_connectEdcdWebSocket, 60_000);
  }
}

// ─── HTTP helpers (handle gzip automatically) ─────────────────────────────────
const zlib = require('zlib');
const HEADERS = {
  'User-Agent':      'EDCD-KenTariiMonitor/6.1',
  'Accept':          'application/json',
  'Accept-Encoding': 'gzip, deflate',
};

function httpGet(url, timeout = 20000) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: HEADERS }, r => {
      const chunks = [];
      r.on('data', c => chunks.push(c));
      r.on('end', () => {
        const buf = Buffer.concat(chunks);
        if (r.statusCode >= 400) {
          return reject(new Error(`HTTP ${r.statusCode} from ${url}`));
        }
        const enc = r.headers['content-encoding'] || '';
        const decompress = enc.includes('gzip')    ? cb => zlib.gunzip(buf, cb)
                         : enc.includes('deflate') ? cb => zlib.inflate(buf, cb)
                         : cb => cb(null, buf);
        decompress((err, data) => {
          if (err) return reject(new Error('Decompress error: ' + err.message));
          try { resolve(JSON.parse(data.toString('utf8'))); }
          catch { reject(new Error('Bad JSON from ' + url)); }
        });
      });
    });
    req.setTimeout(timeout, () => { req.destroy(); reject(new Error('Timeout: ' + url)); });
    req.on('error', reject);
  });
}

function httpPost(url, body, timeout = 20000) {
  return new Promise((resolve, reject) => {
    const buf = Buffer.from(JSON.stringify(body), 'utf8');
    const u   = new URL(url);
    const req = https.request({
      hostname: u.hostname, path: u.pathname + u.search, method: 'POST',
      headers: { ...HEADERS, 'Content-Type': 'application/json', 'Content-Length': buf.length },
    }, r => {
      const chunks = [];
      r.on('data', c => chunks.push(c));
      r.on('end', () => {
        const raw = Buffer.concat(chunks);
        if (r.statusCode >= 400) return reject(new Error(`HTTP ${r.statusCode} from ${url}`));
        const enc = r.headers['content-encoding'] || '';
        const decompress = enc.includes('gzip') ? cb => zlib.gunzip(raw, cb) : cb => cb(null, raw);
        decompress((err, data) => {
          if (err) return reject(err);
          try { resolve(JSON.parse(data.toString('utf8'))); }
          catch { reject(new Error('Bad JSON from ' + url)); }
        });
      });
    });
    req.setTimeout(timeout, () => { req.destroy(); reject(new Error('Timeout: ' + url)); });
    req.on('error', reject);
    req.write(buf);
    req.end();
  });
}
// enc: standard URI encoding; enc27: also encodes apostrophe as %27
const enc   = s => encodeURIComponent(String(s));
const enc27 = s => encodeURIComponent(String(s)).replace(/'/g, '%27');

// ─── Feature 1: Tick History & Prediction ────────────────────────────────────
function loadTickHistory() {
  try {
    if (fs.existsSync(TICK_HISTORY_FILE))
      tickHistory = JSON.parse(fs.readFileSync(TICK_HISTORY_FILE, 'utf8'));
  } catch (e) { console.warn('  [tick] Load failed:', e.message); }
}

function saveTickHistory() {
  try { fs.writeFileSync(TICK_HISTORY_FILE, JSON.stringify(tickHistory, null, 2)); }
  catch (e) { console.warn('  [tick] Save failed:', e.message); }
}

function recordTick(isoTime) {
  tickHistory.push({ time: isoTime, recorded: new Date().toISOString() });
  if (tickHistory.length > 90) tickHistory = tickHistory.slice(-90);
  saveTickHistory();
}

const BGS_TICK_HOUR   = 15;
const BGS_TICK_MINUTE = 50;

function predictNextTick() {
  const now      = new Date();
  const todayTick = new Date(Date.UTC(
    now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(),
    BGS_TICK_HOUR, BGS_TICK_MINUTE, 0, 0
  ));
  const predicted = todayTick > now ? todayTick : new Date(todayTick.getTime() + 86_400_000);
  return {
    predicted:   predicted.toISOString(),
    tickTimeUTC: '15:50 UTC',
    sampleSize:  tickHistory.length,
  };
}

// ─── Post-Tick Monitor ────────────────────────────────────────────────────────
// When a tick is detected, poll Ken'Tarii systems every 20 min for 1 hour,
// diff influence/states against the pre-tick baseline, generate an AI executive
// brief, then broadcast it to all connected clients.

const POST_TICK_POLLS    = 3;          // 3 × 20 min = 1 hour
const POST_TICK_INTERVAL = 20 * 60 * 1000;

let _tickMonitorState = {
  active:    false,
  baseline:  null,   // { [systemName]: { controllingFaction, factions:[...] } }
  pollCount: 0,
  timer:     null,
};

async function _fetchSystemSnapshot(systemNames) {
  const snap = {};
  for (const name of systemNames) {
    try {
      const r = await httpGet(
        `https://elitebgs.app/api/ebgs/v5/systems?name=${encodeURIComponent(name)}&factionDetails=true`,
        20000
      );
      const doc = r.body?.docs?.[0];
      if (!doc) { snap[name] = { error: 'not found' }; continue; }
      snap[name] = {
        controllingFaction: doc.controlling_minor_faction || null,
        factions: (doc.factions || []).map(f => {
          const p = f.faction_details?.faction_presence?.[0] || {};
          return {
            name:          f.name,
            influence:     p.influence != null ? parseFloat((p.influence * 100).toFixed(2)) : null,
            state:         p.state || 'None',
            activeStates:  (p.active_states  || []).map(s => s.state),
            pendingStates: (p.pending_states || []).map(s => s.state),
          };
        }),
      };
    } catch (e) {
      snap[name] = { error: e.message };
    }
  }
  return snap;
}

function _detectTickChanges(before, after) {
  const changes = [];
  for (const sys of Object.keys(after)) {
    const b = before[sys];
    const a = after[sys];
    if (!b || b.error || a.error) continue;

    if (b.controllingFaction !== a.controllingFaction) {
      changes.push({ system: sys, type: 'CONTROL_CHANGE', from: b.controllingFaction, to: a.controllingFaction });
    }
    const bMap = Object.fromEntries((b.factions || []).map(f => [f.name, f]));
    for (const af of (a.factions || [])) {
      const bf = bMap[af.name];
      if (!bf) { changes.push({ system: sys, type: 'FACTION_NEW', faction: af.name, influence: af.influence }); continue; }
      const delta = (af.influence || 0) - (bf.influence || 0);
      if (Math.abs(delta) >= 0.05) {
        changes.push({ system: sys, type: 'INFLUENCE', faction: af.name,
          from: bf.influence, to: af.influence,
          delta: (delta > 0 ? '+' : '') + delta.toFixed(2) + '%' });
      }
      if (bf.state !== af.state) {
        changes.push({ system: sys, type: 'STATE', faction: af.name, from: bf.state, to: af.state });
      }
      const bStates = new Set(bf.activeStates || []);
      const aStates = new Set(af.activeStates || []);
      const entered = [...aStates].filter(s => !bStates.has(s));
      const exited  = [...bStates].filter(s => !aStates.has(s));
      if (entered.length) changes.push({ system: sys, type: 'STATE_ENTERED', faction: af.name, states: entered });
      if (exited.length)  changes.push({ system: sys, type: 'STATE_EXITED',  faction: af.name, states: exited });
    }
  }
  return changes;
}

async function _generateTickBrief(changes, after) {
  const changeText = JSON.stringify(changes, null, 2);
  const stateText  = JSON.stringify(after,   null, 2);
  const prompt =
    `BGS TICK JUST OCCURRED — POST-TICK EXECUTIVE BRIEF\n\n` +
    `DETECTED CHANGES ACROSS ${(squadronConfig.squadronName || DEFAULT_SQUAD).toUpperCase()} SYSTEMS:\n${changeText}\n\n` +
    `CURRENT SYSTEM STATE (post-tick):\n${stateText}\n\n` +
    `Write a concise EXECUTIVE BRIEF with these sections:\n` +
    `## SUMMARY\n(systems checked, how many changed)\n` +
    `## NOTABLE CHANGES\n(per system: what changed, from→to, why it matters for BGS)\n` +
    `## CRITICAL ALERTS\n(wars, elections, retreats, expansions — flag with ⚠)\n` +
    `## RECOMMENDED ACTIONS\n(prioritized tactical steps for next tick cycle)\n` +
    `Be specific: use exact faction names, percentages, system names.`;
  try {
    return await runAIAnalysis(prompt, '');
  } catch (e) {
    return `[Brief generation failed: ${e.message}]\n\nRaw changes:\n${changeText}`;
  }
}

async function startPostTickMonitor() {
  if (_tickMonitorState.active) return;  // already running

  const systemNames = Object.keys(eddn.systemState);
  if (systemNames.length === 0) {
    console.log('  [tick-monitor] No systems seeded yet — skipping post-tick monitoring.');
    return;
  }

  _tickMonitorState.active    = true;
  _tickMonitorState.pollCount = 0;

  console.log(`  [tick-monitor] Starting — capturing baseline for ${systemNames.length} systems...`);
  broadcast({ type: 'tick_monitor_start', systems: systemNames.length });
  _tickMonitorState.baseline = await _fetchSystemSnapshot(systemNames);
  console.log('  [tick-monitor] Baseline captured. Will poll 3× every 20 min.');

  _tickMonitorState.timer = setInterval(async () => {
    _tickMonitorState.pollCount++;
    const poll = _tickMonitorState.pollCount;
    console.log(`  [tick-monitor] Poll ${poll}/${POST_TICK_POLLS}...`);
    broadcast({ type: 'tick_monitor_poll', poll, total: POST_TICK_POLLS });

    const current = await _fetchSystemSnapshot(systemNames);
    const changes = _detectTickChanges(_tickMonitorState.baseline, current);

    if (changes.length > 0) {
      console.log(`  [tick-monitor] ${changes.length} change(s) detected — generating brief...`);
      const brief = await _generateTickBrief(changes, current);
      broadcast({ type: 'tick_brief', changes, brief, poll, systems: systemNames.length });
      _tickMonitorState.baseline = current;  // update baseline for next poll
    } else {
      broadcast({ type: 'tick_monitor_no_change', poll, total: POST_TICK_POLLS });
      console.log(`  [tick-monitor] Poll ${poll}: no changes yet.`);
    }

    if (poll >= POST_TICK_POLLS) {
      clearInterval(_tickMonitorState.timer);
      _tickMonitorState.active = false;
      console.log('  [tick-monitor] 1-hour window complete.');
      broadcast({ type: 'tick_monitor_done' });
    }
  }, POST_TICK_INTERVAL);
}

// ─── Feature 3: Map Annotations ───────────────────────────────────────────────
function loadAnnotations() {
  try {
    if (fs.existsSync(ANNOTATIONS_FILE))
      mapAnnotations = JSON.parse(fs.readFileSync(ANNOTATIONS_FILE, 'utf8'));
  } catch (e) { console.warn('  [annotations] Load failed:', e.message); }
}

function saveAnnotations() {
  try { fs.writeFileSync(ANNOTATIONS_FILE, JSON.stringify(mapAnnotations, null, 2)); }
  catch (e) { console.warn('  [annotations] Save failed:', e.message); }
}

// ─── Feature 5: Rival Faction ─────────────────────────────────────────────────
function loadRivalConfig() {
  try {
    if (fs.existsSync(RIVAL_FILE))
      rivalConfig = JSON.parse(fs.readFileSync(RIVAL_FILE, 'utf8'));
  } catch (e) { console.warn('  [rival] Load failed:', e.message); }
}

function saveRivalConfig() {
  try { fs.writeFileSync(RIVAL_FILE, JSON.stringify(rivalConfig, null, 2)); }
  catch (e) { console.warn('  [rival] Save failed:', e.message); }
}

function normFactionName(s) {
  return (s || '').toLowerCase().replace(/[''`´\u2018\u2019]/g, "'").trim();
}

async function fetchRivalFactionData(factionName) {
  const normTarget = normFactionName(factionName);

  // ── 0. EDDN live feed (same source as Ken'Tarii tracking) ───────────────────
  // Scan all systems already in memory for this faction's presence
  const eddnSystems = [];
  for (const s of Object.values(eddn.systemState)) {
    if (!s.allFactions?.length) continue;
    const match = s.allFactions.find(f => normFactionName(f.name) === normTarget);
    if (match) {
      eddnSystems.push({
        system:        s.system,
        influence:     match.influence || 0,
        state:         match.state || 'None',
        activeStates:  match.activeStates  || [],
        pendingStates: match.pendingStates || [],
        source:        'EDDN-live',
        lastSeen:      s.lastSeen,
      });
    }
  }
  if (eddnSystems.length) {
    console.log(`  [rival] EDDN live: ${eddnSystems.length} systems for "${factionName}"`);
    return eddnSystems;
  }

  const toSystems = (arr, src) => arr.map(p => ({
    system:        p.system_name || p.name,
    influence:     (p.influence > 1 ? p.influence / 100 : p.influence) || 0,
    state:         p.state || 'None',
    activeStates:  (p.active_states  || p.activeStates  || []).map(s => s.state || s),
    pendingStates: (p.pending_states || p.pendingStates || []).map(s => s.state || s),
    source:        src,
  }));

  // ── 1. EliteBGS ─────────────────────────────────────────────────────────────
  try {
    const r   = await httpGet(`https://elitebgs.app/api/ebgs/v5/factions?name=${enc(factionName)}&page=0`, 20000);
    const doc = r?.docs?.[0];
    if (doc?.faction_presence?.length) {
      console.log(`  [rival] EliteBGS: ${doc.faction_presence.length} systems for "${factionName}"`);
      return toSystems(doc.faction_presence, 'EliteBGS');
    }
  } catch (e) { console.warn(`  [rival] EliteBGS failed: ${e.message}`); }

  // ── 2. Spansh ────────────────────────────────────────────────────────────────
  const spanshAttempts = [
    () => httpPost('https://spansh.co.uk/api/v2/factions/search',
      { filters: { name: { value: factionName, comparison: '=' } }, sort: [], size: 1, page: 0 }, 20000),
    () => httpGet(`https://spansh.co.uk/api/v2/factions?q=${enc27(factionName)}&size=1`, 18000),
    () => httpGet(`https://spansh.co.uk/api/factions?name=${enc27(factionName)}`, 18000),
  ];
  for (const attempt of spanshAttempts) {
    try {
      const r       = await attempt();
      const faction = r?.results?.[0] || r?.factions?.[0] || (Array.isArray(r) ? r[0] : null);
      const sysArr  = faction?.systems || faction?.presence || [];
      if (sysArr.length) {
        console.log(`  [rival] Spansh: ${sysArr.length} systems for "${factionName}"`);
        return toSystems(sysArr.map(s => ({ system_name: s.name || s.system_name, ...s })), 'Spansh');
      }
    } catch { /* try next */ }
  }

  // ── 3. EDSM ──────────────────────────────────────────────────────────────────
  for (const ename of [enc27(factionName), enc(factionName)]) {
    try {
      const r       = await httpGet(`https://www.edsm.net/api-v1/factions?factionName=${ename}`, 18000);
      const faction = Array.isArray(r) ? r[0] : (r?.name ? r : null);
      const sysArr  = faction?.systems || [];
      if (sysArr.length) {
        console.log(`  [rival] EDSM: ${sysArr.length} systems for "${factionName}"`);
        return toSystems(sysArr.map(s => ({
          system_name: s.name, influence: s.influence || 0, state: s.state || 'None',
          activeStates:  (s.activeStates  || []).map(st => st.state || st),
          pendingStates: (s.pendingStates || []).map(st => st.state || st),
        })), 'EDSM');
      }
    } catch { /* try next */ }
  }

  // ── 4. Partial-name EDDN scan (for spelling variations) ──────────────────────
  const partial = normTarget.split(' ').filter(w => w.length > 3);
  if (partial.length) {
    const partialMatches = [];
    for (const s of Object.values(eddn.systemState)) {
      for (const f of (s.allFactions || [])) {
        const fn = normFactionName(f.name);
        if (partial.every(w => fn.includes(w))) {
          const existing = partialMatches.find(x => x.system === s.system);
          if (!existing) partialMatches.push({
            system: s.system, influence: f.influence || 0, state: f.state || 'None',
            activeStates: f.activeStates || [], pendingStates: f.pendingStates || [],
            source: 'EDDN-partial', matchedName: f.name,
          });
        }
      }
    }
    if (partialMatches.length) {
      const matchedName = partialMatches[0].matchedName;
      console.log(`  [rival] EDDN partial match "${matchedName}": ${partialMatches.length} systems`);
      return partialMatches;
    }
  }

  throw new Error(`Faction "${factionName}" not found in EDDN live data, EliteBGS, Spansh, or EDSM. It will appear automatically once any CMDR submits telemetry from a system where they are present. Try the exact in-game faction name.`);
}

// ─── Feature 6: User Accounts ─────────────────────────────────────────────────
function loadUsersDb() {
  try {
    if (fs.existsSync(USERS_FILE))
      usersDb = JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
  } catch (e) { console.warn('  [users] Load failed:', e.message); }
}

function saveUsersDb() {
  try { fs.writeFileSync(USERS_FILE, JSON.stringify(usersDb, null, 2)); }
  catch (e) { console.warn('  [users] Save failed:', e.message); }
}

function hashPassword(password, salt) {
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, 64, (err, buf) => {
      if (err) return reject(err);
      resolve(buf.toString('hex'));
    });
  });
}

async function verifyPassword(password, salt, storedHash) {
  const hash = await hashPassword(password, salt);
  return hash === storedHash;
}

// ─── System seeder ────────────────────────────────────────────────────────────
// Pulls all Ken'Tarii Mandate systems from EliteBGS or EDSM and seeds the
// dashboard grid so CMDRs see all systems immediately, not just EDDN-observed ones.

async function seedKenTariiSystems() {
  const factionName = squadronConfig.squadronName || DEFAULT_SQUAD;
  console.log(`  [seed] Fetching ${factionName} systems...`);

  // ── 1. EliteBGS ───────────────────────────────────────────────────────────
  try {
    const r   = await httpGet(`https://elitebgs.app/api/ebgs/v5/factions?name=${enc(factionName)}&page=0`, 30000);
    const doc = r?.docs?.[0];
    if (doc?.faction_presence?.length) {
      const systems = doc.faction_presence.map(p => ({
        system:           p.system_name,
        influence:        p.influence           || 0,
        state:            p.state               || 'None',
        activeStates:     (p.active_states      || []).map(s => s.state),
        pendingStates:    (p.pending_states     || []).map(s => s.state),
        recoveringStates: (p.recovering_states  || []).map(s => s.state),
        seedSource:       'EliteBGS',
      }));
      const count = eddn.seedSystems(systems);
      console.log(`  [seed] Seeded ${count} systems from EliteBGS (${systems.length} total).`);
      return;
    }
  } catch (e) { console.warn(`  [seed] EliteBGS: ${e.message}`); }

  // ── 2. Spansh — try multiple endpoint patterns ────────────────────────────
  const spanshAttempts = [
    // v2 search POST
    () => httpPost('https://spansh.co.uk/api/v2/factions/search',
      { filters: { name: { value: factionName, comparison: '=' } }, sort: [], size: 1, page: 0 }, 25000),
    // v2 GET with q param
    () => httpGet(`https://spansh.co.uk/api/v2/factions?q=${enc27(factionName)}&size=1`, 20000),
    // v1 GET with name param
    () => httpGet(`https://spansh.co.uk/api/factions?name=${enc27(factionName)}`, 20000),
  ];

  for (const attempt of spanshAttempts) {
    try {
      const r      = await attempt();
      const faction = r?.results?.[0] || r?.factions?.[0] || (Array.isArray(r) ? r[0] : null);
      const sysArr  = faction?.systems || faction?.presence || [];
      if (sysArr.length) {
        const systems = sysArr.map(s => ({
          system:       s.name || s.system_name,
          influence:    s.influence > 1 ? s.influence / 100 : (s.influence || 0),
          state:        s.state || 'None',
          activeStates: s.active_states || s.activeStates || [],
          seedSource:   'Spansh',
        }));
        const count = eddn.seedSystems(systems);
        console.log(`  [seed] Seeded ${count} systems from Spansh (${systems.length} total).`);
        return;
      }
    } catch (e) { /* try next */ }
  }
  console.warn('  [seed] Spansh: all endpoint patterns failed');

  // ── 3. EDSM — try both apostrophe encodings ───────────────────────────────
  for (const ename of [enc27(factionName), enc(factionName)]) {
    try {
      const r       = await httpGet(`https://www.edsm.net/api-v1/factions?factionName=${ename}`, 20000);
      const faction = Array.isArray(r) ? r[0] : (r?.name ? r : null);
      const sysArr  = faction?.systems || [];
      if (sysArr.length) {
        const systems = sysArr.map(s => ({
          system:        s.name,
          influence:     s.influence || 0,
          state:         s.state || 'None',
          activeStates:  (s.activeStates  || []).map(st => st.state || st),
          pendingStates: (s.pendingStates || []).map(st => st.state || st),
          seedSource:    'EDSM',
        }));
        const count = eddn.seedSystems(systems);
        console.log(`  [seed] Seeded ${count} systems from EDSM (${systems.length} total).`);
        return;
      }
    } catch (e) { /* try next */ }
  }
  console.warn('  [seed] EDSM: all attempts failed');

  console.warn("  [seed] All sources failed — retrying in 3 minutes. EDDN populates grid live in the meantime.");
}

// ─── EDSM single-system helper ────────────────────────────────────────────────
async function edsmSystemFactions(systemName) {
  const r = await httpGet(`https://www.edsm.net/api-system-v1/factions?systemName=${enc(systemName)}`);
  if (!r.name) return null;
  return {
    source: 'EDSM',
    system: r.name,
    controllingFaction: r.controllingFaction?.name || null,
    factions: (r.factions || []).sort((a, b) => b.influence - a.influence).map(f => ({
      name: f.name, influence: f.influence,
      state: f.state, allegiance: f.allegiance, government: f.government,
      activeStates:     (f.activeStates     || []).map(s => s.state),
      pendingStates:    (f.pendingStates    || []).map(s => s.state),
      recoveringStates: (f.recoveringStates || []).map(s => s.state),
      isPlayer: f.isPlayer || false,
    })),
  };
}

// ─── EDSM system info helper (population, security, economy) ─────────────────
async function edsmSystemInfo(systemName) {
  const r = await httpGet(`https://www.edsm.net/api-v1/system?systemName=${enc(systemName)}&showInformation=1`);
  if (!r?.name) return null;
  return {
    population:  r.information?.population  ?? 0,
    security:    r.information?.security    ?? null,
    economy:     r.information?.economy     ?? null,
    government:  r.information?.government  ?? null,
    allegiance:  r.information?.allegiance  ?? null,
  };
}

// ─── AI providers ─────────────────────────────────────────────────────────────
const MODEL_CHAIN = ['gemini-2.5-flash', 'gemini-2.0-flash'];

// lastUsedModel persists to disk so the UI shows the correct AI after server restarts
let lastUsedModel = null;
// quotaExhausted tracks when each provider hit its rate limit { 'gemini': timestamp, ... }
let quotaExhausted = {};
try {
  if (fs.existsSync(AI_STATE_FILE)) {
    const s = JSON.parse(fs.readFileSync(AI_STATE_FILE, 'utf8'));
    lastUsedModel  = s.lastUsedModel  || null;
    quotaExhausted = s.quotaExhausted || {};
  }
} catch {}
function saveAIState() {
  try { fs.writeFileSync(AI_STATE_FILE, JSON.stringify({ lastUsedModel, quotaExhausted })); } catch {}
}
function isQuotaError(e) {
  const msg = e.message || '';
  return msg.includes('429') || msg.includes('quota') || msg.includes('RESOURCE_EXHAUSTED') || msg.includes('rate_limit');
}
// Returns true if the provider has hit quota within the last hour
function isProviderExhausted(id) {
  const ts = quotaExhausted[id];
  if (!ts) return false;
  if (Date.now() - ts > 3600000) { delete quotaExhausted[id]; return false; }
  return true;
}
// Model strings used to identify each provider in the UI
const PROVIDER_MODELS = {
  gemini:      'gemini-2.5-flash',
  groq:        `groq/${GROQ_MODEL}`,
  openrouter:  `openrouter/${OPENROUTER_MODEL}`,
  mistral:     `mistral/${MISTRAL_MODEL}`,
};
// Returns the first provider in the fallback chain that isn't quota-exhausted
function getActiveProvider() {
  if (genAI        && !isProviderExhausted('gemini'))     return { id: 'gemini',     label: 'GEMINI 2.5', model: PROVIDER_MODELS.gemini };
  if (groqClient   && !isProviderExhausted('groq'))       return { id: 'groq',       label: 'GROQ LLAMA', model: PROVIDER_MODELS.groq };
  if (OPENROUTER_KEY && !isProviderExhausted('openrouter')) return { id: 'openrouter', label: 'OPENROUTER', model: PROVIDER_MODELS.openrouter };
  if (MISTRAL_KEY)                                        return { id: 'mistral',    label: 'MISTRAL',    model: PROVIDER_MODELS.mistral };
  return { id: 'none', label: 'NOT CONFIGURED', model: null };
}
// Probe AI providers on startup — tests Gemini with a minimal request so we know its real status
async function probeAIProviders() {
  if (genAI && !isProviderExhausted('gemini')) {
    try {
      const m = genAI.getGenerativeModel({ model: 'gemini-2.0-flash' });
      await m.generateContent('Reply with: OK');
      console.log('  [AI] Gemini probe: OK');
    } catch (err) {
      if (isQuotaError(err)) {
        quotaExhausted['gemini'] = Date.now();
        saveAIState();
        console.log('  [AI] Gemini probe: QUOTA EXHAUSTED — active provider:', getActiveProvider().label);
      } else {
        console.log('  [AI] Gemini probe error:', err.message);
      }
    }
  } else if (isProviderExhausted('gemini')) {
    console.log('  [AI] Gemini: quota exhausted (persisted) — active provider:', getActiveProvider().label);
  }
}

function getAnalystPrompt() {
  const sq = squadronConfig.squadronName || DEFAULT_SQUAD;
  return `You are an AI Strategist for ${sq} — an Elite Dangerous player faction.
Analyze the provided EDDN logs and system data. Focus exclusively on systems where ${sq} has presence. Filter out noise.

What to report:
- **Influence Shifts** — Gains and losses since last BGS tick, retreat risks (below 5%), expansion opportunities (above 75%)
- **Combat Actions** — Bounties redeemed, kill bonds, faction conflict outcomes
- **Economic Shifts** — Trade missions completed, market activity, exploration data sold
- **Foreign Interference** — Rival squadron or NPC faction activity threatening ${sq} systems

Output rules:
- Use **bold** for system names, factions, and critical percentages
- Flag Wars and Elections with ⚠ — they are time-critical
- Sort by urgency: active conflicts → retreat risks → expansion candidates → stable systems
- End with 3–5 specific action items for CMDRs today`;
}

async function runGeminiAnalysis(prompt, context) {
  if (!genAI) throw Object.assign(new Error('Gemini API key not configured.'), { isQuota: true });
  let idx = 0;
  while (idx < MODEL_CHAIN.length) {
    try {
      const model  = genAI.getGenerativeModel({ model: MODEL_CHAIN[idx], generationConfig: { maxOutputTokens: 2048, temperature: 0.5 } });
      const result = await model.generateContent([
        { text: getAnalystPrompt() },
        { text: `LIVE INTELLIGENCE DATA:\n${context}\n\nQUERY: ${prompt}` },
      ]);
      return { text: result.response.text(), model: MODEL_CHAIN[idx] };
    } catch (err) {
      if (isQuotaError(err) && idx + 1 < MODEL_CHAIN.length) { idx++; continue; }
      throw err;
    }
  }
}

async function runGroqAnalysis(prompt, context) {
  if (!groqClient) throw new Error('Groq API key not configured.');
  const completion = await groqClient.chat.completions.create({
    messages: [
      { role: 'system', content: getAnalystPrompt() },
      { role: 'user',   content: `LIVE INTELLIGENCE DATA:\n${context}\n\nQUERY: ${prompt}` },
    ],
    model:       GROQ_MODEL,
    max_tokens:  2048,
    temperature: 0.5,
  });
  const text = completion.choices[0]?.message?.content || '';
  if (!text) throw new Error('Groq returned empty response.');
  return { text, model: `groq/${GROQ_MODEL}` };
}

async function runOpenRouterAnalysis(prompt, context) {
  if (!OPENROUTER_KEY) throw new Error('OpenRouter API key not configured.');
  const response = await axios.post(
    'https://openrouter.ai/api/v1/chat/completions',
    {
      model:       OPENROUTER_MODEL,
      messages: [
        { role: 'system', content: getAnalystPrompt() },
        { role: 'user',   content: `LIVE INTELLIGENCE DATA:\n${context}\n\nQUERY: ${prompt}` },
      ],
      max_tokens:  2048,
      temperature: 0.5,
    },
    {
      headers: {
        'Authorization': `Bearer ${OPENROUTER_KEY}`,
        'Content-Type':  'application/json',
        'HTTP-Referer':  'http://localhost:3000',
        'X-Title':       `${squadronConfig.squadronName || DEFAULT_SQUAD} Intelligence`,
      },
      timeout: 60000,
    }
  );
  const text = response.data?.choices?.[0]?.message?.content || '';
  if (!text) throw new Error('OpenRouter returned empty response.');
  return { text, model: `openrouter/${OPENROUTER_MODEL}` };
}

async function runMistralAnalysis(prompt, context) {
  if (!MISTRAL_KEY) throw new Error('Mistral API key not configured.');
  const response = await axios.post(
    'https://api.mistral.ai/v1/chat/completions',
    {
      model:       MISTRAL_MODEL,
      messages: [
        { role: 'system', content: getAnalystPrompt() },
        { role: 'user',   content: `LIVE INTELLIGENCE DATA:\n${context}\n\nQUERY: ${prompt}` },
      ],
      max_tokens:  2048,
      temperature: 0.5,
    },
    {
      headers: {
        'Authorization': `Bearer ${MISTRAL_KEY}`,
        'Content-Type':  'application/json',
      },
      timeout: 60000,
    }
  );
  const text = response.data?.choices?.[0]?.message?.content || '';
  if (!text) throw new Error('Mistral returned empty response.');
  return { text, model: `mistral/${MISTRAL_MODEL}` };
}

// Fallback chain: Gemini 2.5 → Gemini 2.0 → Groq LLaMA → OpenRouter LLaMA → Mistral Ministral 8B
async function runAIAnalysis(prompt, context) {
  function trackModel(result) {
    if (result.model !== lastUsedModel) { lastUsedModel = result.model; saveAIState(); }
    return result;
  }
  if (genAI && !isProviderExhausted('gemini')) {
    try {
      return trackModel(await runGeminiAnalysis(prompt, context));
    } catch (err) {
      if (isQuotaError(err)) {
        quotaExhausted['gemini'] = Date.now();
        saveAIState();
        console.log('  [AI] Gemini quota hit — falling back to Groq...');
      } else { throw err; }
    }
  }
  if (groqClient && !isProviderExhausted('groq')) {
    try {
      return trackModel(await runGroqAnalysis(prompt, context));
    } catch (err) {
      if (isQuotaError(err) || err.message?.includes('503') || err.message?.includes('unavailable')) {
        quotaExhausted['groq'] = Date.now();
        saveAIState();
        console.log('  [AI] Groq unavailable — falling back to OpenRouter...');
      } else { throw err; }
    }
  }
  if (OPENROUTER_KEY && !isProviderExhausted('openrouter')) {
    try {
      return trackModel(await runOpenRouterAnalysis(prompt, context));
    } catch (err) {
      if (isQuotaError(err) || err.message?.includes('503') || err.message?.includes('unavailable')) {
        quotaExhausted['openrouter'] = Date.now();
        saveAIState();
        console.log('  [AI] OpenRouter unavailable — falling back to Mistral...');
      } else { throw err; }
    }
  }
  return trackModel(await runMistralAnalysis(prompt, context));
}

function buildContext(hoursBack = 4, systemFilter = null) {
  const events  = eddn.getEventsInRange(hoursBack);
  const systems = eddn.getSystemsSnapshot();
  const stats   = eddn.getStats();

  let ctx = `=== ${(squadronConfig.squadronName || DEFAULT_SQUAD).toUpperCase()} INTELLIGENCE REPORT ===\n`;
  ctx += `Generated: ${new Date().toISOString()}\n`;
  ctx += `EDDN live events (last ${hoursBack}h): ${events.length}\n`;
  ctx += `Total systems tracked: ${systems.length} (${systems.filter(s=>!s.seeded).length} with live EDDN data)\n`;
  if (stats.tickDetected) ctx += `BGS TICK DETECTED at: ${stats.tickTime}\n`;
  ctx += '\n';

  const relevant = systemFilter
    ? systems.filter(s => s.system.toLowerCase().includes(systemFilter.toLowerCase()))
    : systems.slice(0, 60);

  if (relevant.length > 0) {
    ctx += '=== SYSTEM STATUS ===\n';
    for (const s of relevant) {
      const inf = (s.influence * 100).toFixed(2);
      const risk = s.influence < 0.05 ? ' ⚠ RETREAT RISK' : s.influence < 0.10 ? ' ⚠ LOW' : s.influence > 0.75 ? ' ★ EXPANSION ELIGIBLE' : '';
      ctx += `\n• ${s.system}${s.seeded ? ' [seeded]' : ' [LIVE]'}\n`;
      ctx += `  Influence: ${inf}%${risk}`;
      if (s.activeStates.length)    ctx += ` | Active: ${s.activeStates.join(', ')}`;
      if (s.pendingStates.length)   ctx += ` | Pending: ${s.pendingStates.join(', ')}`;
      ctx += `\n  Activity: ${s.eventCount1h}/1h | ${s.eventCount24h}/24h`;
      if (s.lastSeen) ctx += ` | Last EDDN: ${s.lastSeen.slice(11,19)} UTC`;
      ctx += '\n';
      if (s.allFactions?.length > 0) {
        ctx += `  All factions: ${s.allFactions.map(f => `${f.name} ${(f.influence*100).toFixed(1)}%`).join(', ')}\n`;
      }
    }
  }

  if (events.length > 0) {
    ctx += `\n=== RECENT EDDN EVENTS (last ${hoursBack}h, newest first) ===\n`;
    for (const ev of events.slice(-50).reverse()) {
      ctx += `[${ev.timestamp.slice(11,19)}] ${ev.event} | ${ev.system} | ${(ev.mandate.influence*100).toFixed(2)}%`;
      if (ev.mandate.activeStates.length) ctx += ` [${ev.mandate.activeStates.join('|')}]`;
      ctx += '\n';
    }
  } else {
    ctx += '\n=== EDDN STATUS: Listener active. Showing seeded baseline data. ===\n';
    ctx += 'Live influence changes will appear as CMDRs submit telemetry.\n';
  }
  return ctx;
}

// ─── Setup / Config routes ────────────────────────────────────────────────────

app.get('/api/config', (_req, res) => {
  res.json({
    setupComplete:      squadronConfig.setupComplete,
    squadronName:       squadronConfig.squadronName,
    initials:           squadronConfig.initials,
    primaryColor:       squadronConfig.primaryColor,
    accentColor:        squadronConfig.accentColor,
    highlightColor:     squadronConfig.highlightColor,
    inaraSquadronName:  squadronConfig.inaraSquadronName,
    hasGemini:          !!process.env.GEMINI_API_KEY,
    hasGroq:            !!process.env.GROQ_API_KEY,
    hasInara:           !!process.env.INARA_API_KEY,
  });
});

app.post('/api/setup', express.json(), async (req, res) => {
  const { squadronName, initials, primaryColor, accentColor, highlightColor,
          inaraSquadronName, leadershipKey, devKey,
          geminiKey, groqKey, openrouterKey, mistralKey, inaraKey } = req.body || {};

  if (!squadronName || !squadronName.trim()) return res.status(400).json({ ok: false, error: 'Squadron name required' });
  if (!leadershipKey || leadershipKey.length < 6) return res.status(400).json({ ok: false, error: 'Leadership password must be at least 6 characters' });
  if (!devKey        || devKey.length        < 6) return res.status(400).json({ ok: false, error: 'Dev password must be at least 6 characters' });

  // Save squadron config
  squadronConfig = {
    setupComplete:     true,
    squadronName:      squadronName.trim(),
    initials:          (initials || '').trim() || deriveInitials(squadronName),
    primaryColor:      primaryColor   || '#00d4ff',
    accentColor:       accentColor    || '#00ff88',
    highlightColor:    highlightColor || '#ff8800',
    inaraSquadronName: inaraSquadronName || squadronName.trim(),
  };
  saveSquadronConfig();

  // Write all config to .env
  const envPath = path.join(__dirname, '.env');
  let envContent = '';
  try { envContent = fs.readFileSync(envPath, 'utf8'); } catch { envContent = ''; }

  function setEnvKey(content, key, value) {
    if (!value) return content;
    const re = new RegExp(`^${key}=.*$`, 'm');
    const line = `${key}=${value}`;
    return re.test(content) ? content.replace(re, line) : content + `\n${line}`;
  }

  envContent = setEnvKey(envContent, 'GEMINI_API_KEY',     geminiKey);
  envContent = setEnvKey(envContent, 'GROQ_API_KEY',       groqKey);
  envContent = setEnvKey(envContent, 'OPENROUTER_API_KEY', openrouterKey);
  envContent = setEnvKey(envContent, 'MISTRAL_API_KEY',    mistralKey);
  envContent = setEnvKey(envContent, 'INARA_API_KEY',      inaraKey);
  envContent = setEnvKey(envContent, 'DEFAULT_SQUADRON',   squadronName.trim());
  envContent = setEnvKey(envContent, 'LEADERSHIP_KEY',     leadershipKey);
  envContent = setEnvKey(envContent, 'DEV_KEY',            devKey);

  try { fs.writeFileSync(envPath, envContent.trim() + '\n'); } catch (e) {
    console.warn('  [setup] Could not write .env:', e.message);
  }

  // Apply all to current process so server works without restart
  if (geminiKey)     process.env.GEMINI_API_KEY    = geminiKey;
  if (groqKey)       process.env.GROQ_API_KEY      = groqKey;
  if (inaraKey)      process.env.INARA_API_KEY     = inaraKey;
  if (leadershipKey) process.env.LEADERSHIP_KEY    = leadershipKey;
  if (devKey)        process.env.DEV_KEY            = devKey;

  // Update EDDN listener's target faction live (no restart needed)
  eddn.targetFaction = squadronConfig.squadronName;
  eddn.targetNorm    = squadronConfig.squadronName.toLowerCase().replace(/[''`´]/g, "'").trim();
  const lc = squadronConfig.squadronName.toLowerCase().replace(/[^a-z']/g, '');
  eddn.targetKeyword = lc;
  eddn.targetLocKey  = lc.replace(/'/g, '');

  // Re-seed systems for the new faction immediately
  seedKenTariiSystems().catch(e => console.warn('  [setup] Re-seed error:', e.message));

  res.json({ ok: true, config: squadronConfig });
});

// ─── Leadership auth / lockdown ───────────────────────────────────────────────
// ─── API routes ───────────────────────────────────────────────────────────────

app.post('/api/auth', (req, res) => {
  const { key } = req.body || {};
  const DEV_K = process.env.DEV_KEY || 'L1vewire!';
  if (key && key.toLowerCase() === DEV_K.toLowerCase()) return res.json({ ok: true, isDev: true });
  res.json({ ok: key === LEADERSHIP_KEY });
});

app.post('/api/lockdown', (req, res) => {
  const { key } = req.body || {};
  if (key !== LEADERSHIP_KEY) return res.status(401).json({ ok: false });
  lockdownActive = true;
  broadcast({ type: 'lockdown', active: true });
  console.log('  [LOCKDOWN] Emergency lockdown activated.');
  res.json({ ok: true });
});

app.post('/api/unlock', (req, res) => {
  const { key } = req.body || {};
  if (key !== LEADERSHIP_KEY) return res.status(401).json({ ok: false, message: 'Invalid cipher' });
  lockdownActive = false;
  broadcast({ type: 'lockdown', active: false });
  console.log('  [LOCKDOWN] System unlocked.');
  res.json({ ok: true });
});

app.get('/api/live', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');   // prevent nginx/ngrok proxy buffering
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.flushHeaders();
  sseClients.add(res);
  res.write(`data: ${JSON.stringify({
    type:     'init',
    stats:    eddn.getStats(),
    systems:  eddn.getSystemsSnapshot(),
    lockdown: lockdownActive,
  })}\n\n`);
  // Keepalive comment every 25s so proxies don't close the connection
  const keepalive = setInterval(() => {
    try { res.write(': keepalive\n\n'); } catch { clearInterval(keepalive); }
  }, 25000);
  req.on('close', () => { clearInterval(keepalive); sseClients.delete(res); });
});

app.get('/api/systems', (_req, res) => res.json(eddn.getSystemsSnapshot()));

app.get('/api/system/:name', async (req, res) => {
  const name    = decodeURIComponent(req.params.name);
  const cached  = eddn.systemState[name];
  let edsm      = null;
  let sysInfo   = null;
  try { [edsm, sysInfo] = await Promise.all([edsmSystemFactions(name), edsmSystemInfo(name)]); } catch {}
  res.json({ cached, edsm, sysInfo });
});

app.get('/api/history', (req, res) => {
  const hours  = Math.min(parseInt(req.query.hours) || 4, 72);
  const system = req.query.system || null;
  let events   = eddn.getEventsInRange(hours);
  if (system) events = events.filter(e => e.system.toLowerCase().includes(system.toLowerCase()));
  res.json({ hours, count: events.length, events: events.slice(-500) });
});

app.get('/api/stats',    (_req, res) => res.json(eddn.getStats()));
app.get('/api/diag',     (_req, res) => res.json(eddn.getDiagLog()));
app.get('/api/rawsample', (_req, res) => res.json(eddn.getRawSample()));

// ─── AI Status ────────────────────────────────────────────────────────────────
// Returns which providers are configured and which is currently active (not quota-exhausted).
// The order matches the fallback chain in runAIAnalysis.
app.get('/api/ai/status', (_req, res) => {
  const chain = [];
  if (genAI)          chain.push({ id: 'gemini',     label: 'GEMINI 2.5', exhausted: isProviderExhausted('gemini') });
  if (groqClient)     chain.push({ id: 'groq',       label: 'GROQ LLAMA', exhausted: isProviderExhausted('groq') });
  if (OPENROUTER_KEY) chain.push({ id: 'openrouter', label: 'OPENROUTER', exhausted: isProviderExhausted('openrouter') });
  if (MISTRAL_KEY)    chain.push({ id: 'mistral',    label: 'MISTRAL',    exhausted: false });
  const primary = chain[0] || { id: 'none', label: 'NOT CONFIGURED' };
  const active  = getActiveProvider();
  res.json({ primary, active, chain, configured: chain.length, lastUsed: lastUsedModel });
});

app.get('/api/contrib/:name', (req, res) => {
  const c = eddn.getContributions(decodeURIComponent(req.params.name));
  if (!c) return res.status(404).json({ error: 'No EDDN data found for that CMDR' });
  res.json(c);
});

app.get('/api/contributors', (_req, res) => res.json(eddn.getAllContributors()));

// ─── Activity Log & Medal System ─────────────────────────────────────────────
const ACTIVITY_FILE = path.join(__dirname, 'data', 'activity_log.json');

const MEDALS = {
  // ── Missions ────────────────────────────────────────────────────────────────
  OPERATIVE:        { id:'OPERATIVE',        name:'Operative',                   icon:'⭐', tier:1, category:'Missions',    desc:'Completed first mission for The Ken\'Tarii Mandate in a Mandate system.' },
  AGENT:            { id:'AGENT',            name:'Agent',                       icon:'⭐⭐', tier:2, category:'Missions',    desc:'Completed 10+ missions benefiting The Ken\'Tarii Mandate.' },
  SENIOR_AGENT:     { id:'SENIOR_AGENT',     name:'Senior Agent',                icon:'⭐⭐⭐', tier:3, category:'Missions',  desc:'Completed 50+ missions — a reliable asset of the Mandate.' },
  HANDLER:          { id:'HANDLER',          name:'Handler',                     icon:'🌟', tier:4, category:'Missions',    desc:'Completed 200+ missions — a cornerstone of Mandate operations.' },
  // ── Bounties ────────────────────────────────────────────────────────────────
  ROOKIE_HUNTER:    { id:'ROOKIE_HUNTER',    name:'Rookie Hunter',               icon:'🎯', tier:1, category:'Bounties',    desc:'Redeemed first bounty vouchers in a Ken\'Tarii system.' },
  VIGILANTE:        { id:'VIGILANTE',        name:'Vigilante',                   icon:'🎯🎯', tier:2, category:'Bounties',  desc:'Redeemed 5M+ cr in bounties in Mandate systems.' },
  MARSHAL:          { id:'MARSHAL',          name:'Marshal',                     icon:'🎯🎯🎯', tier:3, category:'Bounties', desc:'Redeemed 25M+ cr in bounties — law and order enforced.' },
  SHERIFF:          { id:'SHERIFF',          name:'Sheriff of the Mandate',      icon:'⚖️', tier:4, category:'Bounties',    desc:'Redeemed 100M+ cr in bounties. The Mandate\'s top law enforcer.' },
  // ── Combat Bonds ────────────────────────────────────────────────────────────
  COMBATANT:        { id:'COMBATANT',        name:'Combatant',                   icon:'⚔️', tier:1, category:'Combat',      desc:'Earned first combat bond fighting for the Mandate.' },
  VETERAN:          { id:'VETERAN',          name:'Veteran',                     icon:'⚔️⚔️', tier:2, category:'Combat',    desc:'Earned 10M+ cr in combat bonds for Mandate conflicts.' },
  ELITE_OPERATIVE:  { id:'ELITE_OPERATIVE',  name:'Elite Operative',             icon:'⚔️⚔️⚔️', tier:3, category:'Combat', desc:'Earned 50M+ cr in combat bonds — battlefield proven.' },
  KNIGHT:           { id:'KNIGHT',           name:'Knight of the Mandate',       icon:'🗡️', tier:4, category:'Combat',      desc:'Earned 200M+ cr in combat bonds. The finest warrior of the Mandate.' },
  // ── Trade ───────────────────────────────────────────────────────────────────
  MERCHANT:         { id:'MERCHANT',         name:'Merchant',                    icon:'💰', tier:1, category:'Trade',       desc:'First trade completed in a Ken\'Tarii system.' },
  TRADER:           { id:'TRADER',           name:'Trader',                      icon:'💰💰', tier:2, category:'Trade',     desc:'Generated 10M+ cr in trade profit in Mandate systems.' },
  TYCOON:           { id:'TYCOON',           name:'Tycoon',                      icon:'💰💰💰', tier:3, category:'Trade',   desc:'Generated 50M+ cr trade profit — economic powerhouse.' },
  ECONOMIC_ADVISOR: { id:'ECONOMIC_ADVISOR', name:'Economic Advisor',            icon:'👑', tier:4, category:'Trade',       desc:'Generated 200M+ cr in trade. Drives the Mandate economy.' },
  // ── Exploration ─────────────────────────────────────────────────────────────
  SCOUT:            { id:'SCOUT',            name:'Scout',                       icon:'🔭', tier:1, category:'Exploration', desc:'First exploration data sold in a Ken\'Tarii system.' },
  PATHFINDER:       { id:'PATHFINDER',       name:'Pathfinder',                  icon:'🔭🔭', tier:2, category:'Exploration', desc:'Sold 10M+ cr in exploration data in Mandate systems.' },
  PIONEER:          { id:'PIONEER',          name:'Pioneer',                     icon:'🔭🔭🔭', tier:3, category:'Exploration', desc:'Sold 50M+ cr in exploration data — expanding Mandate knowledge.' },
  CARTOGRAPHER:     { id:'CARTOGRAPHER',     name:'Cartographer of the Mandate', icon:'🗺️', tier:4, category:'Exploration', desc:'Sold 200M+ cr in exploration data. Maps the Mandate\'s future.' },
  // ── General ─────────────────────────────────────────────────────────────────
  MANDATE_DEFENDER: { id:'MANDATE_DEFENDER', name:'Mandate Defender',            icon:'🛡️', tier:1, category:'General',    desc:'Actively contributed in 3+ Ken\'Tarii systems.' },
  MANDATE_CHAMPION: { id:'MANDATE_CHAMPION', name:'Mandate Champion',            icon:'🛡️🛡️', tier:2, category:'General', desc:'Actively contributed in 10+ Ken\'Tarii systems.' },
  MANDATE_VANGUARD: { id:'MANDATE_VANGUARD', name:'Mandate Vanguard',            icon:'🚀', tier:3, category:'General',    desc:'Contributed across 3+ different activity types for the Mandate.' },
  MANDATE_LEGEND:   { id:'MANDATE_LEGEND',   name:'Mandate Legend',              icon:'🌠', tier:4, category:'General',    desc:'Distinguished across 4+ activity types in 5+ systems. A true legend.' },
};

let activityLog = { cmdrs: {}, recentActivity: [] };

function _loadActivityLog() {
  try {
    if (fs.existsSync(ACTIVITY_FILE))
      activityLog = JSON.parse(fs.readFileSync(ACTIVITY_FILE, 'utf8'));
  } catch (e) { console.warn('  [activity] Load failed:', e.message); }
}
_loadActivityLog();

function _saveActivityLog() {
  try { fs.writeFileSync(ACTIVITY_FILE, JSON.stringify(activityLog, null, 2)); }
  catch (e) { console.warn('  [activity] Save failed:', e.message); }
}

function _isKTSystem(sys) { return !!sys && !!eddn.systemState[sys]; }
const _ktNorm = s => (s || '').toLowerCase().replace(/[''`´]/g, "'").trim();
function getKTNorm() { return _ktNorm(squadronConfig.squadronName || DEFAULT_SQUAD); }

function calcSubmissionStats(events) {
  const stats = { missionCount:0, missionRewards:0, bountiesRedeemed:0, combatBonds:0, tradeProfit:0, explorationData:0, systemsWorked:new Set(), activityTypes:new Set() };
  for (const e of events) {
    const inKT = _isKTSystem(e.system);
    if (e.event === 'MissionCompleted') {
      const forMandate = _ktNorm(e.faction) === getKTNorm();
      const affectsMandate = forMandate || (e.factionEffects||[]).some(fe => _ktNorm(fe.Faction||fe.faction) === getKTNorm());
      if (affectsMandate || inKT) {
        stats.missionCount++;
        stats.missionRewards += e.reward || 0;
        if (e.system) stats.systemsWorked.add(e.system);
        stats.activityTypes.add('missions');
      }
    }
    if ((e.event === 'BountyRedeemed' || e.event === 'RedeemVoucher') && inKT) {
      stats.bountiesRedeemed += e.reward || 0;
      stats.systemsWorked.add(e.system);
      stats.activityTypes.add('bounties');
    }
    if (e.event === 'FactionKillBond' && inKT) {
      stats.combatBonds += e.reward || 0;
      stats.systemsWorked.add(e.system);
      stats.activityTypes.add('combat');
    }
    if (e.event === 'MarketSell' && inKT) {
      stats.tradeProfit += e.reward || 0;
      stats.systemsWorked.add(e.system);
      stats.activityTypes.add('trade');
    }
    if ((e.event === 'SellExplorationData' || e.event === 'MultiSellExplorationData') && inKT) {
      stats.explorationData += e.reward || 0;
      stats.systemsWorked.add(e.system);
      stats.activityTypes.add('exploration');
    }
  }
  stats.systemsWorked = [...stats.systemsWorked];
  stats.activityTypes = [...stats.activityTypes];
  return stats;
}

function calcMedals(t) {
  const m = [];
  if (t.missionCount >= 1)    m.push('OPERATIVE');
  if (t.missionCount >= 10)   m.push('AGENT');
  if (t.missionCount >= 50)   m.push('SENIOR_AGENT');
  if (t.missionCount >= 200)  m.push('HANDLER');
  if (t.bountiesRedeemed >= 1)         m.push('ROOKIE_HUNTER');
  if (t.bountiesRedeemed >= 5e6)       m.push('VIGILANTE');
  if (t.bountiesRedeemed >= 25e6)      m.push('MARSHAL');
  if (t.bountiesRedeemed >= 100e6)     m.push('SHERIFF');
  if (t.combatBonds >= 1)              m.push('COMBATANT');
  if (t.combatBonds >= 10e6)           m.push('VETERAN');
  if (t.combatBonds >= 50e6)           m.push('ELITE_OPERATIVE');
  if (t.combatBonds >= 200e6)          m.push('KNIGHT');
  if (t.tradeProfit >= 1)              m.push('MERCHANT');
  if (t.tradeProfit >= 10e6)           m.push('TRADER');
  if (t.tradeProfit >= 50e6)           m.push('TYCOON');
  if (t.tradeProfit >= 200e6)          m.push('ECONOMIC_ADVISOR');
  if (t.explorationData >= 1)          m.push('SCOUT');
  if (t.explorationData >= 10e6)       m.push('PATHFINDER');
  if (t.explorationData >= 50e6)       m.push('PIONEER');
  if (t.explorationData >= 200e6)      m.push('CARTOGRAPHER');
  const sys  = (t.systemsWorked||[]).length;
  const acts = (t.activityTypes||[]).length;
  if (sys >= 3)             m.push('MANDATE_DEFENDER');
  if (sys >= 10)            m.push('MANDATE_CHAMPION');
  if (acts >= 3)            m.push('MANDATE_VANGUARD');
  if (acts >= 4 && sys >= 5) m.push('MANDATE_LEGEND');
  return m;
}

function recordActivity(cmdrName, subStats) {
  const key = cmdrName.toLowerCase().trim();
  if (!activityLog.cmdrs[key]) {
    activityLog.cmdrs[key] = {
      displayName: cmdrName, medals: [], submissionCount: 0,
      lastSubmission: null, recentSubmissions: [],
      totalStats: { missionCount:0, missionRewards:0, bountiesRedeemed:0, combatBonds:0, tradeProfit:0, explorationData:0, systemsWorked:[], activityTypes:[] },
    };
  }
  const c = activityLog.cmdrs[key];
  c.displayName = cmdrName;
  const t = c.totalStats;
  t.missionCount     += subStats.missionCount;
  t.missionRewards   += subStats.missionRewards;
  t.bountiesRedeemed += subStats.bountiesRedeemed;
  t.combatBonds      += subStats.combatBonds;
  t.tradeProfit      += subStats.tradeProfit;
  t.explorationData  += subStats.explorationData;
  t.systemsWorked    = [...new Set([...t.systemsWorked, ...subStats.systemsWorked])];
  t.activityTypes    = [...new Set([...t.activityTypes, ...subStats.activityTypes])];
  const oldSet   = new Set(c.medals);
  c.medals       = calcMedals(t);
  const newMedals = c.medals.filter(m => !oldSet.has(m));
  c.submissionCount++;
  c.lastSubmission = new Date().toISOString();
  c.recentSubmissions = [{ timestamp: c.lastSubmission, stats: subStats, newMedals }, ...c.recentSubmissions].slice(0, 10);
  activityLog.recentActivity = [{
    ts: c.lastSubmission, cmdrName,
    systems:      subStats.systemsWorked.slice(0, 6),
    missionCount: subStats.missionCount,
    bountiesRedeemed: subStats.bountiesRedeemed,
    combatBonds:  subStats.combatBonds,
    tradeProfit:  subStats.tradeProfit,
    explorationData: subStats.explorationData,
    activityTypes: subStats.activityTypes,
    newMedals,
  }, ...activityLog.recentActivity].slice(0, 100);
  _saveActivityLog();
  return { newMedals, totalMedals: c.medals };
}

app.get('/api/activity',       (_req, res) => res.json({ recentActivity: activityLog.recentActivity.slice(0, 50), totalCmdrs: Object.keys(activityLog.cmdrs).length }));
app.get('/api/commendations',  (_req, res) => res.json({
  cmdrs: Object.values(activityLog.cmdrs)
    .map(c => ({ displayName: c.displayName, medals: c.medals, totalStats: c.totalStats, submissionCount: c.submissionCount, lastSubmission: c.lastSubmission }))
    .sort((a, b) => b.medals.length - a.medals.length),
  medalDefs: MEDALS,
}));

// ─── Journal log analysis ─────────────────────────────────────────────────────
const journalCooldowns = new Map(); // cmdrKey → timestamp of last analysis
const JOURNAL_COOLDOWN_MS = 12 * 60 * 60 * 1000;

function buildJournalContext(cmdrName, events) {
  const systems = eddn.getSystemsSnapshot();
  let ctx = `=== CMDR ${cmdrName} — JOURNAL ANALYSIS ===\n`;
  ctx += `Submitted: ${new Date().toISOString()}\n`;
  ctx += `Journal events (last 24h): ${events.length}\n\n`;

  // Group by event type
  const byType = {};
  for (const e of events) { (byType[e.event] = byType[e.event] || []).push(e); }

  if (byType.MissionCompleted?.length) {
    ctx += `=== MISSIONS COMPLETED (${byType.MissionCompleted.length}) ===\n`;
    for (const e of byType.MissionCompleted) {
      ctx += `• ${(e.timestamp||'').slice(11,19)} | ${e.system || '?'} | ${e.faction || '?'} | ${(e.reward||0).toLocaleString()} cr`;
      if (e.missionName) ctx += ` | ${e.missionName}`;
      // Faction effects
      if (e.factionEffects?.length) {
        const effects = e.factionEffects.flatMap(f => (f.Effects||[]).map(x => `${f.Faction}: ${x.Effect} (${x.Trend})`));
        if (effects.length) ctx += ` | Effects: ${effects.join(', ')}`;
      }
      ctx += '\n';
    }
    ctx += '\n';
  }
  const bounties = [...(byType.BountyRedeemed||[]), ...(byType.RedeemVoucher||[])];
  if (bounties.length) {
    ctx += `=== BOUNTIES / VOUCHERS (${bounties.length}) ===\n`;
    for (const e of bounties) ctx += `• ${(e.timestamp||'').slice(11,19)} | ${e.system||'?'} | ${(e.reward||0).toLocaleString()} cr\n`;
    ctx += '\n';
  }
  if (byType.FactionKillBond?.length) {
    ctx += `=== COMBAT BONDS (${byType.FactionKillBond.length}) ===\n`;
    for (const e of byType.FactionKillBond) ctx += `• ${(e.timestamp||'').slice(11,19)} | ${e.system||'?'} | ${(e.reward||0).toLocaleString()} cr\n`;
    ctx += '\n';
  }
  if (byType.MarketSell?.length) {
    ctx += `=== TRADE SALES (${byType.MarketSell.length}) ===\n`;
    for (const e of byType.MarketSell) ctx += `• ${(e.timestamp||'').slice(11,19)} | ${e.system||'?'} | ${(e.reward||0).toLocaleString()} cr\n`;
    ctx += '\n';
  }
  if ((byType.SellExplorationData||[]).length + (byType.MultiSellExplorationData||[]).length > 0) {
    const expl = [...(byType.SellExplorationData||[]), ...(byType.MultiSellExplorationData||[])];
    ctx += `=== EXPLORATION DATA (${expl.length}) ===\n`;
    for (const e of expl) ctx += `• ${(e.timestamp||'').slice(11,19)} | ${e.system||'?'} | ${(e.reward||0).toLocaleString()} cr\n`;
    ctx += '\n';
  }

  ctx += `=== CURRENT ${(squadronConfig.squadronName || DEFAULT_SQUAD).toUpperCase()} SYSTEM STATES ===\n`;
  for (const s of systems.slice(0, 25)) {
    ctx += `• ${s.system}: ${(s.influence*100).toFixed(1)}%`;
    if (s.activeStates?.length) ctx += ` [${s.activeStates.join(', ')}]`;
    ctx += '\n';
  }
  return ctx;
}

app.post('/api/journal-analyze', async (req, res) => {
  const { cmdrName, events } = req.body || {};
  if (!cmdrName || !Array.isArray(events) || !events.length)
    return res.status(400).json({ error: 'cmdrName and events array required' });

  const key     = cmdrName.toLowerCase().trim();
  const lastRun = journalCooldowns.get(key);
  if (lastRun && Date.now() - lastRun < JOURNAL_COOLDOWN_MS) {
    const next = new Date(lastRun + JOURNAL_COOLDOWN_MS);
    return res.status(429).json({ error: `Rate limited — next analysis available after ${next.toLocaleTimeString()} (12h cooldown)` });
  }

  try {
    const context = buildJournalContext(cmdrName, events);
    const query   = `Give CMDR ${cmdrName} a detailed personal BGS contribution report. What did they accomplish? Which systems did they help? How effective were their efforts for ${squadronConfig.squadronName || DEFAULT_SQUAD}? Be specific with numbers.`;
    const result  = await runAIAnalysis(query, context);
    journalCooldowns.set(key, Date.now());
    const subStats  = calcSubmissionStats(events);
    const medalInfo = recordActivity(cmdrName, subStats);
    res.json({ text: result.text, model: result.model, eventCount: events.length, subStats, newMedals: medalInfo.newMedals, totalMedals: medalInfo.totalMedals });
  } catch (e) {
    const msg = isQuotaError(e) ? 'AI quota exhausted — all providers unavailable. Try again later.' : e.message;
    res.status(500).json({ error: msg });
  }
});

app.post('/api/seed', async (_req, res) => {
  try {
    await seedKenTariiSystems();
    res.json({ ok: true, systems: Object.keys(eddn.systemState).length });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── AI response cache ────────────────────────────────────────────────────────
// Each cache key = queryHash → { text, model, generatedAt, eventCount }
// Serve cached result if: same query + data has < 10% more events + < 20 min old
const aiCache  = new Map();
const AI_TTL   = 20 * 60 * 1000;   // 20 minutes
const AI_EVENT_DRIFT = 0.10;        // allow 10% more events before busting cache

function cacheKey(q, hours, system) { return `${q}|${hours}|${system||''}`; }

function getCachedAnswer(q, hours, system) {
  const key    = cacheKey(q, hours, system);
  const cached = aiCache.get(key);
  if (!cached) return null;
  const age      = Date.now() - cached.generatedAt;
  const nowCount = eddn.getEventsInRange(hours).length;
  const drift    = cached.eventCount > 0 ? (nowCount - cached.eventCount) / cached.eventCount : nowCount;
  if (age < AI_TTL && drift < AI_EVENT_DRIFT) return cached;
  return null;
}

function setCachedAnswer(q, hours, system, result) {
  aiCache.set(cacheKey(q, hours, system), {
    ...result,
    generatedAt: Date.now(),
    eventCount:  eddn.getEventsInRange(hours).length,
  });
}

app.get('/api/analyze', async (req, res) => {
  const query  = req.query.q || `Give me an executive briefing on current ${squadronConfig.squadronName || DEFAULT_SQUAD} operations.`;
  const hours  = Math.min(parseInt(req.query.hours) || 4, 72);
  const system = req.query.system || null;
  const force  = req.query.force === '1';

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.flushHeaders();

  // ── Serve from cache if fresh ────────────────────────────────────────────
  if (!force) {
    const cached = getCachedAnswer(query, hours, system);
    if (cached) {
      const ageMin = Math.round((Date.now() - cached.generatedAt) / 60000);
      res.write(`data: ${JSON.stringify({ type: 'answer', text: cached.text, model: cached.model, cached: true, ageMin })}\n\n`);
      res.end();
      return;
    }
  }

  res.write(`data: ${JSON.stringify({ type: 'thinking' })}\n\n`);

  try {
    let context = buildContext(hours, system);

    if (eddn.events.length === 0 && system) {
      try {
        const edsm = await edsmSystemFactions(system);
        if (edsm) {
          context += `\n=== EDSM DATA for ${system} ===\n`;
          context += `Controlling faction: ${edsm.controllingFaction}\n`;
          for (const f of edsm.factions) {
            context += `• ${f.name}: ${(f.influence*100).toFixed(2)}%`;
            if (f.activeStates.length) context += ` [${f.activeStates.join(', ')}]`;
            context += '\n';
          }
        }
      } catch {}
    }

    const result = await runAIAnalysis(query, context);
    setCachedAnswer(query, hours, system, result);
    res.write(`data: ${JSON.stringify({ type: 'answer', text: result.text, model: result.model, cached: false, ageMin: 0 })}\n\n`);
  } catch (err) {
    const msg = isQuotaError(err) ? 'AI quota exhausted — all providers unavailable. Try again later.' : err.message;
    res.write(`data: ${JSON.stringify({ type: 'error', message: msg })}\n\n`);
  }
  res.end();
});

// ─── Inara routes ─────────────────────────────────────────────────────────────
const inaraCache = { squadron: null, squadronAt: 0, cmdrs: {} };
const INARA_TTL  = 60 * 60 * 1000;

app.get('/api/squadron', async (_req, res) => {
  if (!INARA_KEY) return res.status(503).json({ error: 'INARA_API_KEY not configured in .env' });
  const now = Date.now();
  if (inaraCache.squadron && now - inaraCache.squadronAt < INARA_TTL)
    return res.json({ source: 'cache', ...inaraCache.squadron });
  try {
    // Try exact squadron name, then fallback without "The " prefix
    let data = null;
    const namesToTry = [DEFAULT_SQUAD, DEFAULT_SQUAD.replace(/^The /i, '')];
    let lastErr = null;
    for (const name of namesToTry) {
      try { data = await Inara.getSquadron(INARA_KEY, name); break; }
      catch (e) { lastErr = e; console.warn(`  [Inara] squadron "${name}" failed: ${e.message}`); }
    }
    if (!data) throw lastErr;
    inaraCache.squadron = data; inaraCache.squadronAt = now;
    res.json({ source: 'inara', ...data });
  } catch (e) {
    console.error('  [Inara] /api/squadron error:', e.message);
    res.status(502).json({ error: e.message });
  }
});

app.get('/api/cmdr/:name', async (req, res) => {
  if (!INARA_KEY) return res.status(503).json({ error: 'INARA_API_KEY not configured in .env' });
  const name = req.params.name; const now = Date.now();
  const cached = inaraCache.cmdrs[name];
  if (cached && now - cached.at < INARA_TTL) return res.json({ source: 'cache', ...cached.data });
  try {
    const data = await Inara.getCmdr(INARA_KEY, name);
    inaraCache.cmdrs[name] = { data, at: now };
    res.json({ source: 'inara', ...data });
  } catch (e) { res.status(502).json({ error: e.message }); }
});

app.post('/api/inara/refresh', (_req, res) => {
  inaraCache.squadron = null; inaraCache.squadronAt = 0; inaraCache.cmdrs = {};
  res.json({ ok: true });
});

// ─── Feature 1 API: Tick Prediction ──────────────────────────────────────────
app.get('/api/tick/predict', (_req, res) => res.json(predictNextTick()));
app.get('/api/tick/history', (_req, res) => res.json({ history: tickHistory.slice(-30), prediction: predictNextTick() }));

// ─── Feature 3 API: War Table Annotations ────────────────────────────────────
app.get('/api/map/annotations', (_req, res) => res.json({ annotations: mapAnnotations }));

app.post('/api/map/annotate', (req, res) => {
  const { key, type, x, y, x2, y2, label, color } = req.body || {};
  if (key !== LEADERSHIP_KEY) return res.status(401).json({ ok: false });
  const annotation = { id: Date.now(), type, x, y, x2, y2, label: label || '', color: color || '#00d4ff' };
  mapAnnotations.push(annotation);
  saveAnnotations();
  broadcast({ type: 'annotation', action: 'add', annotation });
  res.json({ ok: true, annotation });
});

app.delete('/api/map/annotate/:id', (req, res) => {
  const { key } = req.body || {};
  if (key !== LEADERSHIP_KEY) return res.status(401).json({ ok: false });
  const id = parseInt(req.params.id);
  mapAnnotations = mapAnnotations.filter(a => a.id !== id);
  saveAnnotations();
  broadcast({ type: 'annotation', action: 'remove', id });
  res.json({ ok: true });
});

app.delete('/api/map/annotations/clear', (req, res) => {
  const { key } = req.body || {};
  if (key !== LEADERSHIP_KEY) return res.status(401).json({ ok: false });
  mapAnnotations = [];
  saveAnnotations();
  broadcast({ type: 'annotation', action: 'clear' });
  res.json({ ok: true });
});

// ─── Feature 4 API: BGS Optimizer ────────────────────────────────────────────
function diminishingReturn(value, threshold) {
  if (value <= threshold) return 1.0;
  return threshold / value;
}

const THRESHOLDS = { missions: 15, bounties: 5_000_000, combat: 10_000_000, trade: 8_000_000, exploration: 5_000_000 };

app.post('/api/bgs/optimize', async (req, res) => {
  const { cmdrName, systemStats } = req.body || {};
  if (!cmdrName || !Array.isArray(systemStats)) return res.status(400).json({ error: 'cmdrName and systemStats required' });

  const efficiencies = [];
  for (const ss of systemStats) {
    efficiencies.push({ system: ss.system, activity: 'Missions',    efficiency: diminishingReturn(ss.missionCount  || 0, THRESHOLDS.missions),    note: `${ss.missionCount || 0}/${THRESHOLDS.missions} threshold` });
    efficiencies.push({ system: ss.system, activity: 'Bounties',    efficiency: diminishingReturn(ss.bounties      || 0, THRESHOLDS.bounties),    note: `${((ss.bounties || 0) / 1e6).toFixed(1)}M/${THRESHOLDS.bounties/1e6}M threshold` });
    efficiencies.push({ system: ss.system, activity: 'Combat',      efficiency: diminishingReturn(ss.combatBonds   || 0, THRESHOLDS.combat),      note: `${((ss.combatBonds || 0) / 1e6).toFixed(1)}M/${THRESHOLDS.combat/1e6}M threshold` });
    efficiencies.push({ system: ss.system, activity: 'Trade',       efficiency: diminishingReturn(ss.trade         || 0, THRESHOLDS.trade),        note: `${((ss.trade || 0) / 1e6).toFixed(1)}M/${THRESHOLDS.trade/1e6}M threshold` });
    efficiencies.push({ system: ss.system, activity: 'Exploration', efficiency: diminishingReturn(ss.exploration   || 0, THRESHOLDS.exploration),  note: `${((ss.exploration || 0) / 1e6).toFixed(1)}M/${THRESHOLDS.exploration/1e6}M threshold` });
  }
  efficiencies.sort((a, b) => b.efficiency - a.efficiency);

  const ctxLines = ['BGS OPTIMIZER REQUEST:', `CMDR: ${cmdrName}`, '', 'Activity efficiencies (1.0 = full return, lower = diminishing returns):'];
  for (const e of efficiencies.slice(0, 15)) {
    ctxLines.push(`  ${e.system} / ${e.activity}: ${(e.efficiency * 100).toFixed(0)}% efficiency (${e.note})`);
  }
  const context = ctxLines.join('\n');
  const prompt  = `Based on the BGS diminishing returns data above, give CMDR ${cmdrName} specific optimization recommendations. Which system+activity combos have the most room left before hitting diminishing returns? What should they prioritize today for maximum BGS impact? Be specific and tactical.`;

  try {
    const result = await runAIAnalysis(prompt, context);
    res.json({ recommendations: result.text, model: result.model, efficiencies });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ─── Feature 5 API: Rival Faction ────────────────────────────────────────────
app.post('/api/rival/set', async (req, res) => {
  const { key, faction } = req.body || {};
  if (key !== LEADERSHIP_KEY) return res.status(401).json({ ok: false });
  if (!faction) return res.status(400).json({ error: 'faction name required' });
  try {
    const data = await fetchRivalFactionData(faction);
    rivalConfig = { faction, lastFetch: Date.now(), data };
    saveRivalConfig();
    broadcast({ type: 'rival_update', faction, data });
    res.json({ ok: true, data });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Search all factions seen in EDDN live data — lets leadership find exact names
app.get('/api/rival/search', (req, res) => {
  const q = (req.query.q || '').toLowerCase().trim();
  if (q.length < 2) return res.json({ factions: [] });
  const seen = new Map(); // name → { name, systemCount, sampleInfluence }
  for (const s of Object.values(eddn.systemState)) {
    for (const f of (s.allFactions || [])) {
      if (!f.name) continue;
      const fn = f.name.toLowerCase();
      if (fn.includes(q)) {
        const entry = seen.get(f.name) || { name: f.name, systemCount: 0, sampleInfluence: f.influence };
        entry.systemCount++;
        seen.set(f.name, entry);
      }
    }
  }
  const factions = [...seen.values()].sort((a, b) => b.systemCount - a.systemCount).slice(0, 20);
  res.json({ factions, eddnSystemCount: Object.keys(eddn.systemState).length });
});

app.get('/api/rival/data', async (_req, res) => {
  if (!rivalConfig.faction) return res.json({ faction: null, systems: [], lastFetch: 0 });
  // Always re-scan EDDN live data (zero latency, same as Ken'Tarii tracking)
  // Fall back to cached external data if EDDN hasn't seen this faction yet
  try {
    const fresh = await fetchRivalFactionData(rivalConfig.faction);
    if (fresh.length) {
      rivalConfig.data      = fresh;
      rivalConfig.lastFetch = Date.now();
      saveRivalConfig();
    }
  } catch {}
  res.json({ faction: rivalConfig.faction, systems: rivalConfig.data || [], lastFetch: rivalConfig.lastFetch });
});

app.delete('/api/rival/clear', (req, res) => {
  const { key } = req.body || {};
  if (key !== LEADERSHIP_KEY) return res.status(401).json({ ok: false });
  rivalConfig = { faction: null, lastFetch: 0, data: null };
  saveRivalConfig();
  broadcast({ type: 'rival_update', faction: null, data: [] });
  res.json({ ok: true });
});

// ─── Feature 6 API: User Accounts ────────────────────────────────────────────
app.post('/api/users/register', async (req, res) => {
  const { cmdrName, password, confirmPassword } = req.body || {};
  if (!cmdrName || cmdrName.length < 3) return res.status(400).json({ ok: false, error: 'CMDR name must be at least 3 characters' });
  if (!password || password.length < 6) return res.status(400).json({ ok: false, error: 'Password must be at least 6 characters' });
  if (password !== confirmPassword) return res.status(400).json({ ok: false, error: 'Passwords do not match' });
  const key = cmdrName.toLowerCase().trim();
  if (usersDb[key]) return res.status(400).json({ ok: false, error: 'CMDR name already registered' });
  try {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = await hashPassword(password, salt);
    usersDb[key] = { cmdrName, salt, hash, registered: new Date().toISOString(), lastLogin: null, rank: 'Recruit', announcements: [] };
    saveUsersDb();
    res.json({ ok: true, cmdrName });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.post('/api/users/login', async (req, res) => {
  const { cmdrName, password } = req.body || {};
  if (!cmdrName || !password) return res.status(400).json({ ok: false, error: 'Missing credentials' });
  const key  = cmdrName.toLowerCase().trim();
  const user = usersDb[key];
  if (!user) return res.json({ ok: false, error: 'CMDR not found' });
  try {
    const valid = await verifyPassword(password, user.salt, user.hash);
    if (!valid) return res.json({ ok: false, error: 'Invalid password' });
    user.lastLogin = new Date().toISOString();
    saveUsersDb();
    res.json({ ok: true, cmdrName: user.cmdrName, rank: user.rank, registered: user.registered, announcements: user.announcements || [], theme: user.theme || null });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

app.post('/api/users/theme', (req, res) => {
  const { cmdrName, theme } = req.body || {};
  if (!cmdrName || !theme) return res.status(400).json({ ok: false, error: 'Missing fields' });
  const key  = cmdrName.toLowerCase().trim();
  const user = usersDb[key];
  if (!user) return res.status(404).json({ ok: false, error: 'Not found' });
  // Validate theme fields — only allow hex color strings
  const hexRe = /^#[0-9a-fA-F]{6}$/;
  const clean = {};
  if (theme.primaryColor   && hexRe.test(theme.primaryColor))   clean.primaryColor   = theme.primaryColor;
  if (theme.accentColor    && hexRe.test(theme.accentColor))    clean.accentColor    = theme.accentColor;
  if (theme.highlightColor && hexRe.test(theme.highlightColor)) clean.highlightColor = theme.highlightColor;
  if (theme.panelBg        && hexRe.test(theme.panelBg))        clean.panelBg        = theme.panelBg;
  if (theme.textColor      && hexRe.test(theme.textColor))      clean.textColor      = theme.textColor;
  user.theme = clean;
  saveUsersDb();
  res.json({ ok: true, theme: clean });
});

app.get('/api/users/profile/:name', (req, res) => {
  const key  = req.params.name.toLowerCase().trim();
  const user = usersDb[key];
  if (!user) return res.status(404).json({ error: 'Not found' });
  const actKey = key;
  const submissionCount = activityLog.cmdrs[actKey]?.submissionCount || 0;
  res.json({ cmdrName: user.cmdrName, rank: user.rank, registered: user.registered, lastLogin: user.lastLogin, submissionCount });
});

app.post('/api/users/announce', (req, res) => {
  const { key, message } = req.body || {};
  if (key !== LEADERSHIP_KEY) return res.status(401).json({ ok: false });
  if (!message) return res.status(400).json({ error: 'message required' });
  const announcement = { message, ts: new Date().toISOString() };
  for (const u of Object.values(usersDb)) {
    if (!u.announcements) u.announcements = [];
    u.announcements.push(announcement);
    if (u.announcements.length > 50) u.announcements = u.announcements.slice(-50);
  }
  saveUsersDb();
  broadcast({ type: 'announcement', message, ts: announcement.ts });
  res.json({ ok: true });
});

app.get('/api/users/list', (req, res) => {
  const { key } = req.query;
  if (key !== LEADERSHIP_KEY) return res.status(401).json({ ok: false });
  const list = Object.values(usersDb).map(u => ({ cmdrName: u.cmdrName, rank: u.rank, registered: u.registered, lastLogin: u.lastLogin }));
  res.json({ ok: true, users: list });
});

// ─── Messaging ────────────────────────────────────────────────────────────────
app.post('/api/messages/send', (req, res) => {
  const { key, to, subject, message } = req.body || {};
  if (key !== LEADERSHIP_KEY) return res.status(401).json({ ok: false });
  if (!message) return res.status(400).json({ error: 'message required' });
  const ts = new Date().toISOString();
  const msg = { id: Date.now(), from: 'Leadership', subject: subject || 'Mandate Dispatch', message, ts, read: false };
  if (to === 'all') {
    for (const u of Object.values(usersDb)) {
      if (!u.inbox) u.inbox = [];
      u.inbox.push(msg);
      if (u.inbox.length > 100) u.inbox = u.inbox.slice(-100);
    }
    saveUsersDb();
    broadcast({ type: 'message', to: 'all', msg });
    res.json({ ok: true, sent: Object.keys(usersDb).length });
  } else {
    const userKey = (to || '').toLowerCase().trim();
    const user = usersDb[userKey];
    if (!user) return res.status(404).json({ error: 'CMDR not found' });
    if (!user.inbox) user.inbox = [];
    user.inbox.push(msg);
    if (user.inbox.length > 100) user.inbox = user.inbox.slice(-100);
    saveUsersDb();
    broadcast({ type: 'message', to: userKey, msg });
    res.json({ ok: true, sent: 1 });
  }
});

app.get('/api/messages/:cmdrName', (req, res) => {
  const key = req.params.cmdrName.toLowerCase().trim();
  const user = usersDb[key];
  if (!user) return res.status(404).json({ error: 'Not found' });
  res.json({ inbox: (user.inbox || []).slice(-50).reverse() });
});

app.post('/api/messages/read', (req, res) => {
  const { cmdrName, msgId } = req.body || {};
  const key = (cmdrName || '').toLowerCase().trim();
  const user = usersDb[key];
  if (!user) return res.status(404).json({ error: 'Not found' });
  const m = (user.inbox || []).find(x => x.id === msgId);
  if (m) { m.read = true; saveUsersDb(); }
  res.json({ ok: true });
});

app.post('/api/messages/delete', (req, res) => {
  const { cmdrName, msgId } = req.body || {};
  const key = (cmdrName || '').toLowerCase().trim();
  const user = usersDb[key];
  if (!user) return res.status(404).json({ error: 'Not found' });
  const before = (user.inbox || []).length;
  user.inbox = (user.inbox || []).filter(x => x.id !== msgId);
  if (user.inbox.length < before) saveUsersDb();
  res.json({ ok: true });
});

// Dev activity tracking
app.post('/api/dev/track', (req, res) => {
  const { cmdrName, events } = req.body || {};
  if (!cmdrName || !Array.isArray(events)) return res.status(400).json({ ok: false });
  for (const ev of events.slice(0, 50)) {
    devActivityLog.push({ cmdrName, ...ev, serverTs: new Date().toISOString() });
  }
  if (devActivityLog.length > 5000) devActivityLog = devActivityLog.slice(-5000);
  _saveDevActivityLog();
  res.json({ ok: true });
});

app.get('/api/dev/activity', (req, res) => {
  const devK = process.env.DEV_KEY || 'L1vewire!';
  if (!req.query.key || req.query.key.toLowerCase() !== devK.toLowerCase()) return res.status(401).json({ ok: false });
  const limit = Math.min(parseInt(req.query.limit) || 200, 500);
  res.json({ activity: devActivityLog.slice(-limit).reverse(), total: devActivityLog.length });
});

app.get('/api/dev/users', (req, res) => {
  const devK = process.env.DEV_KEY || 'L1vewire!';
  if (!req.query.key || req.query.key.toLowerCase() !== devK.toLowerCase()) return res.status(401).json({ ok: false });
  const users = Object.values(usersDb).map(u => {
    const k = u.cmdrName.toLowerCase().trim();
    const acts = devActivityLog.filter(e => (e.cmdrName || '').toLowerCase() === k);
    const topMap = {};
    acts.forEach(e => { topMap[e.action] = (topMap[e.action] || 0) + 1; });
    const top = Object.entries(topMap).sort((a,b)=>b[1]-a[1])[0];
    return { cmdrName: u.cmdrName, rank: u.rank, registered: u.registered, lastLogin: u.lastLogin,
      totalActions: acts.length, lastActionTs: acts[acts.length-1]?.ts, topAction: top?.[0],
      submissionCount: activityLog.cmdrs[k]?.submissionCount || 0 };
  });
  res.json({ ok: true, users, totalEvents: devActivityLog.length });
});

// ─── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  loadSquadronConfig();

  console.log(`\n  ╔══════════════════════════════════════════════════╗`);
  console.log(`  ║   ${(squadronConfig.squadronName || 'BGS Analyzer')} Intelligence        ║`);
  console.log(`  ║   http://localhost:${PORT}                            ║`);
  console.log(`  ║   EDDN listener active                           ║`);
  console.log(`  ╚══════════════════════════════════════════════════╝\n`);

  // Load feature data on startup
  loadTickHistory();
  loadAnnotations();
  loadRivalConfig();
  loadUsersDb();

  // Probe AI providers so we know real availability from the start
  setTimeout(() => probeAIProviders().catch(() => {}), 3000);

  // tick.edcd.io: poll REST every 5 minutes + connect WebSocket for real-time push
  _pollEdcdTick();
  setInterval(_pollEdcdTick, 5 * 60 * 1000);
  _connectEdcdWebSocket();

  // Auto-refresh rival faction every 15 minutes
  setInterval(async () => {
    if (!rivalConfig.faction) return;
    try {
      rivalConfig.data     = await fetchRivalFactionData(rivalConfig.faction);
      rivalConfig.lastFetch = Date.now();
      saveRivalConfig();
      broadcast({ type: 'rival_update', faction: rivalConfig.faction, data: rivalConfig.data });
    } catch {}
  }, 15 * 60 * 1000);

  // Seed all known systems — retry every 3 minutes until it succeeds
  async function trySeedWithRetry() {
    const before = Object.keys(eddn.systemState).length;
    await seedKenTariiSystems().catch(e => console.warn('  [seed] Error:', e.message));
    const after = Object.keys(eddn.systemState).length;
    if (after === before) {
      // Nothing seeded — retry in 3 minutes
      setTimeout(trySeedWithRetry, 3 * 60 * 1000);
    }
  }
  setTimeout(trySeedWithRetry, 2000);
});
