/**
 * EDDN Listener — BGS Intelligence Collector
 */

const zmq   = require('zeromq');
const zlib  = require('zlib');
const fs    = require('fs');
const path  = require('path');
const { EventEmitter } = require('events');

const RELAY          = 'tcp://eddn.edcd.io:9500';
const LOG_FILE       = path.join(__dirname, 'data', 'mandate_events.jsonl');
const MAX_MEMORY     = 5000;
const MAX_AGE_MS     = 72 * 60 * 60 * 1000;

function normName(s) {
  return (s || '').toLowerCase().replace(/[\u2018\u2019\u02bc\u0060\u00b4]/g, "'");
}

const BGS_EVENTS = new Set([
  'FSDJump', 'Location', 'CarrierJump', 'Docked',
  'MissionCompleted', 'MultiSellExplorationData',
  'SellExplorationData', 'RedeemVoucher', 'MarketSell',
  'MarketBuy', 'BountyRedeemed', 'FactionKillBond',
]);

// Contribution event types with friendly labels
const CONTRIB_LABELS = {
  MissionCompleted:          'Missions',
  FactionKillBond:           'Kill Bonds',
  BountyRedeemed:            'Bounties',
  MarketSell:                'Trade',
  MarketBuy:                 'Trade',
  SellExplorationData:       'Exploration',
  MultiSellExplorationData:  'Exploration',
  RedeemVoucher:             'Vouchers',
  FSDJump:                   'Navigation',
  Location:                  'Navigation',
  Docked:                    'Navigation',
  CarrierJump:               'Navigation',
};

const TICK_WINDOW_MS = 15 * 60 * 1000;  // 15-minute window to catch rolling tick
const TICK_THRESHOLD = 8;               // 8 distinct systems = confident tick signal

class EDDNListener extends EventEmitter {
  constructor(targetFaction = "The Ken'Tarii Mandate") {
    super();
    this.targetFaction = targetFaction;
    this.targetNorm    = normName(targetFaction);
    const lc = targetFaction.toLowerCase().replace(/[^a-z']/g, '');
    this.targetKeyword = lc;
    this.targetLocKey  = lc.replace(/'/g, '');
    this.events       = [];
    this.systemState  = {};
    this.connected    = false;
    this.msgCount     = 0;
    this.matchCount   = 0;
    this.lastMsg      = null;
    this.sock         = null;
    this.diagLog      = [];   // last 100 BGS events (any faction)
    this.rawSample    = [];   // last 40 raw EDDN messages (all schemas)
    this.contributions = {};  // uploaderID → contribution record
    this.tickDetected = false;
    this.tickTime     = null;
    this.recentInfluenceUpdates = [];
    this._preTickCache = {};  // systemName → [{name, inf}] — last known influence per system
    this._loadLog();
  }

  _mightContainFaction(rawStr) {
    const s = rawStr.toLowerCase();
    return s.includes(this.targetKeyword) || s.includes(this.targetLocKey);
  }

  _loadLog() {
    try {
      if (!fs.existsSync(LOG_FILE)) return;
      const lines  = fs.readFileSync(LOG_FILE, 'utf8').split('\n').filter(Boolean);
      const cutoff = Date.now() - MAX_AGE_MS;
      let loaded   = 0;
      for (const line of lines) {
        try {
          const ev = JSON.parse(line);
          if (new Date(ev.timestamp).getTime() > cutoff) {
            this.events.push(ev);
            this._updateSystemState(ev);
            if (ev.uploaderID) this._trackContribution(ev);
            loaded++;
          }
        } catch {}
      }
      if (loaded) console.log(`  [EDDN] Loaded ${loaded} cached events from log.`);
    } catch (e) {
      console.warn('  [EDDN] Could not load log:', e.message);
    }
  }

  seedSystems(systems) {
    let seeded = 0;
    for (const s of systems) {
      if (this.systemState[s.system]) continue;
      this.systemState[s.system] = {
        system: s.system, influence: s.influence || 0, state: s.state || 'None',
        activeStates: s.activeStates || [], pendingStates: s.pendingStates || [],
        recoveringStates: s.recoveringStates || [], allFactions: s.allFactions || [],
        lastSeen: null, eventCount1h: 0, eventCount24h: 0, recentEvents: [],
        seeded: true, seedSource: s.seedSource || 'unknown',
        seededAt: new Date().toISOString(),
      };
      seeded++;
    }
    this.emit('seeded', this.getSystemsSnapshot());
    return seeded;
  }

  _updateSystemState(ev) {
    if (!ev.system) return;
    if (!this.systemState[ev.system]) {
      this.systemState[ev.system] = {
        system: ev.system, influence: 0, state: 'None',
        activeStates: [], pendingStates: [], recoveringStates: [],
        allFactions: [], lastSeen: ev.timestamp,
        eventCount1h: 0, eventCount24h: 0, recentEvents: [],
      };
    }
    const s    = this.systemState[ev.system];
    s.lastSeen = ev.timestamp;
    s.seeded   = false;
    if (ev.mandate) {
      s.influence        = ev.mandate.influence;
      s.state            = ev.mandate.state;
      s.activeStates     = ev.mandate.activeStates     || [];
      s.pendingStates    = ev.mandate.pendingStates    || [];
      s.recoveringStates = ev.mandate.recoveringStates || [];
    }
    if (ev.allFactions) s.allFactions = ev.allFactions;
    s.recentEvents = [
      { event: ev.event, timestamp: ev.timestamp, uploaderID: ev.uploaderID },
      ...s.recentEvents,
    ].slice(0, 20);
  }

  // ── CMDR contribution tracking ────────────────────────────────────────────────
  _trackContribution(ev) {
    const id = ev.uploaderID;
    if (!id || !ev.system) return;
    if (!this.contributions[id]) {
      this.contributions[id] = {
        id, totalEvents: 0, firstSeen: ev.timestamp, lastSeen: ev.timestamp,
        systems: {}, eventTypes: {},
      };
    }
    const c = this.contributions[id];
    c.totalEvents++;
    c.lastSeen = ev.timestamp;

    // Per-system stats
    if (!c.systems[ev.system]) {
      c.systems[ev.system] = { count: 0, lastSeen: ev.timestamp, influence: null };
    }
    c.systems[ev.system].count++;
    c.systems[ev.system].lastSeen = ev.timestamp;
    if (ev.mandate?.influence != null) {
      c.systems[ev.system].influence = (ev.mandate.influence * 100).toFixed(2) + '%';
    }

    // Event type tally
    const label = CONTRIB_LABELS[ev.event] || ev.event;
    c.eventTypes[label] = (c.eventTypes[label] || 0) + 1;
  }

  getContributions(cmdrName) {
    // Case-insensitive partial match on uploaderID
    const lower = cmdrName.toLowerCase();
    const matches = Object.values(this.contributions).filter(c =>
      c.id.toLowerCase().includes(lower)
    );
    if (!matches.length) return null;
    // Return best match (exact first, then partial)
    const exact = matches.find(c => c.id.toLowerCase() === lower);
    const c = exact || matches[0];
    return {
      id:          c.id,
      totalEvents: c.totalEvents,
      firstSeen:   c.firstSeen,
      lastSeen:    c.lastSeen,
      eventTypes:  c.eventTypes,
      systems:     Object.entries(c.systems)
        .sort((a, b) => b[1].count - a[1].count)
        .slice(0, 30)
        .map(([sys, d]) => ({ system: sys, events: d.count, lastSeen: d.lastSeen, influence: d.influence })),
    };
  }

  getAllContributors() {
    return Object.values(this.contributions)
      .sort((a, b) => b.totalEvents - a.totalEvents)
      .slice(0, 50)
      .map(c => ({ id: c.id, totalEvents: c.totalEvents, systemCount: Object.keys(c.systems).length, lastSeen: c.lastSeen }));
  }

  _refreshActivityCounts() {
    const now = Date.now();
    const h1  = now - 3_600_000;
    const h24 = now - 86_400_000;
    for (const s of Object.values(this.systemState)) { s.eventCount1h = 0; s.eventCount24h = 0; }
    for (const ev of this.events) {
      const t = new Date(ev.timestamp).getTime();
      const s = this.systemState[ev.system];
      if (!s) continue;
      if (t > h1)  s.eventCount1h++;
      if (t > h24) s.eventCount24h++;
    }
  }

  // _checkTick: called for EVERY BGS FSDJump/Location event, any faction.
  // Tracks systems where influence values differ from cached pre-tick values.
  // Fires 'tick' event when TICK_THRESHOLD distinct systems show new influence.
  _checkTick(systemName, factions) {
    const now = Date.now();

    // Drop entries outside the rolling window
    this.recentInfluenceUpdates = this.recentInfluenceUpdates.filter(u => now - u.ts < TICK_WINDOW_MS);

    // Already counted this system in this window
    if (this.recentInfluenceUpdates.some(u => u.system === systemName)) return;

    // Check if at least one faction's influence differs from our cached value.
    // This filters out re-uploads of stale data and focuses on real tick changes.
    let changed = false;
    if (factions && factions.length > 0) {
      const cached = this._preTickCache[systemName];
      if (!cached) {
        // No baseline yet — store it and don't count as a change
        this._preTickCache[systemName] = factions.map(f => ({ name: f.name, inf: f.influence }));
      } else {
        for (const f of factions) {
          const prev = cached.find(c => c.name === f.name);
          if (!prev || Math.abs((prev.inf || 0) - (f.influence || 0)) >= 0.001) {
            changed = true;
            break;
          }
        }
        // Update cache to latest values
        this._preTickCache[systemName] = factions.map(f => ({ name: f.name, inf: f.influence }));
      }
    } else {
      changed = true; // no faction data to compare — count it
    }

    if (!changed) return;

    this.recentInfluenceUpdates.push({ system: systemName, ts: now });

    if (this.recentInfluenceUpdates.length >= TICK_THRESHOLD) {
      const utcHour = new Date().getUTCHours();
      // Suppress re-fire within 12 hours of last tick
      if (!this.tickDetected || (now - new Date(this.tickTime).getTime() > 12 * 3_600_000)) {
        this.tickDetected = true;
        this.tickTime     = new Date().toISOString();
        this.emit('tick', {
          time:     this.tickTime,
          systems:  this.recentInfluenceUpdates.map(u => u.system),
          source:   'eddn',
          inWindow: utcHour >= 13 && utcHour <= 17,
        });
        console.log(`  [TICK] Detected via EDDN at ${this.tickTime} (${this.recentInfluenceUpdates.length} systems changed)`);
      }
    }
  }

  _parse(raw) {
    const schema  = raw.$schemaRef || '';
    const header  = raw.header    || {};
    const msg     = raw.message   || {};
    const event   = msg.event;
    const system  = msg.StarSystem || msg.starsystem || null;

    // ── Raw sample: record EVERY message for the DIAG live feed ──────────────
    const schemaShort = schema.replace('https://eddn.edcd.io/schemas/', '').replace('/1', '');
    this.rawSample.push({
      ts:     new Date().toISOString(),
      schema: schemaShort,
      event:  event  || null,
      system: system || null,
      uploader: header.uploaderID || null,
    });
    if (this.rawSample.length > 40) this.rawSample.shift();

    if (!system || !BGS_EVENTS.has(event)) return null;

    const factions = msg.Factions || msg.factions || [];

    // ── Tick detection: runs on ALL FSDJump/Location events, any faction ──────
    // This is the broad sweep — any system with changed influence counts.
    if ((event === 'FSDJump' || event === 'Location') && factions.length > 0) {
      const allF = factions.map(f => ({
        name:      f.Name      || f.name || '',
        influence: f.Influence ?? f.influence ?? 0,
      }));
      this._checkTick(system, allF);
    }

    // ── Diag: record ALL BGS events so the feed shows activity ───────────────
    const diagEntry = {
      ts:           new Date().toISOString(),
      event,
      system,
      uploader:     header.uploaderID || null,
      factionCount: factions.length,
      factionNames: factions.slice(0, 6).map(f => f.Name || f.name || '?'),
      matched:      false,
    };

    const rawStr = JSON.stringify(msg);
    if (!this._mightContainFaction(rawStr)) {
      this._diagAdd(diagEntry);  // log ALL BGS events, not just ones with factions
      return null;
    }

    const mandate = factions.find(f => normName(f.Name || f.name) === this.targetNorm);
    if (!mandate) {
      diagEntry.nearMiss = factions
        .filter(f => normName(f.Name || f.name).includes(this.targetKeyword.split("'")[0]))
        .map(f => f.Name || f.name);
      this._diagAdd(diagEntry);
      return null;
    }

    diagEntry.matched = true;
    this._diagAdd(diagEntry);

    const toStateArr = (arr) => (arr || []).map(s => s.State || s.state || s).filter(Boolean);

    return {
      timestamp:  new Date().toISOString(),
      gatewayTs:  header.gatewayTimestamp,
      uploaderID: header.uploaderID,
      schema,
      event,
      system,
      mandate: {
        name:             this.targetFaction,
        influence:        mandate.Influence  ?? mandate.influence ?? 0,
        state:            mandate.FactionState || mandate.factionState || 'None',
        activeStates:     toStateArr(mandate.ActiveStates    || mandate.activeStates),
        pendingStates:    toStateArr(mandate.PendingStates   || mandate.pendingStates),
        recoveringStates: toStateArr(mandate.RecoveringStates || mandate.recoveringStates),
        happiness:        mandate.Happiness || mandate.happiness || null,
      },
      allFactions: factions.map(f => ({
        name:          f.Name      || f.name,
        influence:     f.Influence ?? f.influence ?? 0,
        state:         f.FactionState || f.factionState || 'None',
        activeStates:  toStateArr(f.ActiveStates  || f.activeStates),
        pendingStates: toStateArr(f.PendingStates || f.pendingStates),
        isPlayer:      f.SquadronFaction || false,
      })).sort((a, b) => b.influence - a.influence),
      pilot: msg.commanderName || null,
    };
  }

  _diagAdd(entry) {
    this.diagLog.push(entry);
    if (this.diagLog.length > 100) this.diagLog.shift();
    this.emit('diag', entry);
  }

  getDiagLog()        { return this.diagLog.slice().reverse(); }
  getRawSample()      { return this.rawSample.slice().reverse(); }

  _store(ev) {
    fs.appendFile(LOG_FILE, JSON.stringify(ev) + '\n', () => {});
    this.events.push(ev);
    const cutoff = Date.now() - MAX_AGE_MS;
    while (this.events.length > MAX_MEMORY ||
      (this.events.length > 0 && new Date(this.events[0].timestamp).getTime() < cutoff)) {
      this.events.shift();
    }
    this._updateSystemState(ev);
    this._refreshActivityCounts();
    if (ev.uploaderID) this._trackContribution(ev);
    this.matchCount++;
    this.emit('event', ev);
  }

  async start() {
    this.sock = new zmq.Subscriber();
    this.sock.subscribe('');
    console.log(`  [EDDN] Connecting to ${RELAY}...`);
    try {
      await this.sock.connect(RELAY);
      this.connected = true;
      console.log(`  [EDDN] Connected. Monitoring for "${this.targetFaction}"...`);
      this.emit('connected');
    } catch (e) {
      console.error('  [EDDN] Connection failed:', e.message);
      this.emit('error', e);
      return;
    }

    for await (const [compressed] of this.sock) {
      this.msgCount++;
      this.lastMsg = new Date().toISOString();
      try {
        const raw = JSON.parse(zlib.inflateSync(compressed));
        const ev  = this._parse(raw);
        if (ev) this._store(ev);
      } catch {}

      // Rawbeat every 50 messages — sends the live raw stream to the DIAG tab
      if (this.msgCount % 50 === 0) {
        this.emit('rawbeat', {
          msgCount:   this.msgCount,
          matchCount: this.matchCount,
          sample:     this.rawSample.slice(-15).reverse(),
        });
      }
      // Heartbeat every 200 messages
      if (this.msgCount % 200 === 0) {
        this.emit('heartbeat', {
          msgCount: this.msgCount, matchCount: this.matchCount,
          systems: Object.keys(this.systemState).length, connected: this.connected,
        });
      }
    }
  }

  getEventsInRange(hoursBack = 4) {
    const cutoff = Date.now() - hoursBack * 3_600_000;
    return this.events.filter(e => new Date(e.timestamp).getTime() > cutoff);
  }

  getSystemsSnapshot() {
    this._refreshActivityCounts();
    return Object.values(this.systemState).sort((a, b) => {
      const aLive = !a.seeded ? 1 : 0;
      const bLive = !b.seeded ? 1 : 0;
      if (bLive !== aLive) return bLive - aLive;
      const aWar = a.activeStates.some(s => s.includes('War') || s.includes('Election')) ? 1 : 0;
      const bWar = b.activeStates.some(s => s.includes('War') || s.includes('Election')) ? 1 : 0;
      if (bWar !== aWar) return bWar - aWar;
      return b.influence - a.influence;
    });
  }

  getStats() {
    return {
      connected: this.connected, msgCount: this.msgCount,
      matchCount: this.matchCount, systems: Object.keys(this.systemState).length,
      eventBuffer: this.events.length, lastMsg: this.lastMsg,
      tickDetected: this.tickDetected, tickTime: this.tickTime,
      contributorCount: Object.keys(this.contributions).length,
    };
  }
}

module.exports = EDDNListener;
