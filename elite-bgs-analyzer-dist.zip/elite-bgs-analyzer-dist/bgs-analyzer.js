#!/usr/bin/env node

/**
 * Elite Dangerous BGS Analyzer v5
 *
 * Three data sources, one AI brain:
 *
 *   EliteBGS  — "The Tick" tracking, faction influence history,
 *               BGS state changes over time. Gold standard for BGS.
 *   EDSM      — Fallback for system/faction data when EliteBGS is
 *               unavailable. Also provides traffic and sphere searches.
 *   Inara     — Ready to add squadron/cmdr data once app is registered
 *               at inara.cz/elite/settings-api/
 *
 *   Gemini    — AI that decides what data to pull and answers questions.
 *
 * Run: node bgs-analyzer.js
 */

require('dotenv').config();
const { GoogleGenerativeAI } = require('@google/generative-ai');
const https = require('https');
const readline = require('readline');

// ─── Validation ───────────────────────────────────────────────────────────────

if (!process.env.GEMINI_API_KEY) {
  console.error('\n  Error: GEMINI_API_KEY missing in .env\n');
  process.exit(1);
}

// ─── Gemini client ─────────────────────────────────────────────────────────────

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// ─── HTTP helper ──────────────────────────────────────────────────────────────

function httpGet(url, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const req = https.get(
      url,
      { headers: { 'User-Agent': 'EliteBGSAnalyzer/5.0', Accept: 'application/json' } },
      (res) => {
        let data = '';
        res.on('data', (c) => (data += c));
        res.on('end', () => {
          try {
            resolve({ status: res.statusCode, body: JSON.parse(data) });
          } catch {
            reject(new Error(`Non-JSON response from ${url} (status ${res.statusCode})`));
          }
        });
      }
    );
    req.setTimeout(timeoutMs, () => {
      req.destroy();
      reject(new Error(`Request timed out: ${url}`));
    });
    req.on('error', reject);
  });
}

function enc(s) {
  return encodeURIComponent(String(s));
}

// ─── EliteBGS API ─────────────────────────────────────────────────────────────
// The gold standard for BGS: tick tracking, historical influence, state changes.
// No API key needed.

const EliteBGS = {
  BASE: 'https://elitebgs.app/api/ebgs/v5',
  TIMEOUT: 20000,

  async getLatestTick() {
    const r = await httpGet(`${this.BASE}/ticks`, this.TIMEOUT);
    if (!Array.isArray(r.body) || r.body.length === 0) {
      return { error: 'Could not fetch tick data' };
    }
    const tick = r.body[0];
    const tickTime = new Date(tick.time);
    const ageHours = ((Date.now() - tickTime) / 3_600_000).toFixed(1);
    return {
      latestTick: tick.time,
      ageHours: parseFloat(ageHours),
      fresh: parseFloat(ageHours) < 2,
      note:
        parseFloat(ageHours) < 2
          ? 'Data is fresh (tick within last 2 hours)'
          : `Data may be stale — last tick was ${ageHours}h ago`,
    };
  },

  async getSystemBGS(systemName) {
    const r = await httpGet(
      `${this.BASE}/systems?name=${enc(systemName)}&factionDetails=true`,
      this.TIMEOUT
    );
    const doc = r.body?.docs?.[0];
    if (!doc) return { error: `System not found in EliteBGS: ${systemName}` };

    const factions = (doc.factions || []).map((f) => {
      // EliteBGS stores influence as 0–1; most recent history entry has current values
      const latest = f.faction_details?.faction_presence?.[0] || {};
      return {
        name: f.name,
        influence: latest.influence != null
          ? `${(latest.influence * 100).toFixed(2)}%`
          : 'unknown',
        state: latest.state || f.state || 'None',
        activeStates: (latest.active_states || []).map((s) => s.state),
        pendingStates: (latest.pending_states || []).map((s) => s.state),
        recoveringStates: (latest.recovering_states || []).map((s) => s.state),
        happiness: latest.happiness || null,
        isPlayerFaction: f.is_player_faction || false,
        lastUpdated: latest.updated_at || null,
      };
    });

    // Sort by influence descending
    factions.sort((a, b) => {
      const ai = parseFloat(a.influence) || 0;
      const bi = parseFloat(b.influence) || 0;
      return bi - ai;
    });

    return {
      source: 'EliteBGS',
      system: doc.name,
      allegiance: doc.allegiance,
      government: doc.government,
      security: doc.security,
      population: doc.population,
      primaryEconomy: doc.primary_economy,
      controllingFaction: doc.controlling_minor_faction,
      updatedAt: doc.updated_at,
      factions,
    };
  },

  async getFactionBGS(factionName) {
    const r = await httpGet(
      `${this.BASE}/factions?name=${enc(factionName)}&systemDetails=true`,
      this.TIMEOUT
    );
    const doc = r.body?.docs?.[0];
    if (!doc) return { error: `Faction not found in EliteBGS: ${factionName}` };

    const presence = (doc.faction_presence || []).map((p) => ({
      system: p.system_name,
      influence: p.influence != null ? `${(p.influence * 100).toFixed(2)}%` : 'unknown',
      state: p.state || 'None',
      activeStates: (p.active_states || []).map((s) => s.state),
      pendingStates: (p.pending_states || []).map((s) => s.state),
      recoveringStates: (p.recovering_states || []).map((s) => s.state),
      happiness: p.happiness || null,
      updatedAt: p.updated_at || null,
    }));

    // Sort by influence descending
    presence.sort((a, b) => {
      const ai = parseFloat(a.influence) || 0;
      const bi = parseFloat(b.influence) || 0;
      return bi - ai;
    });

    return {
      source: 'EliteBGS',
      name: doc.name,
      allegiance: doc.allegiance,
      government: doc.government,
      isPlayerFaction: doc.is_player_faction,
      homeSystem: doc.home_system_name,
      systemCount: presence.length,
      presence,
    };
  },

  async getSystemBGSHistory(systemName, days = 7) {
    // Fetch recent history to show influence trends
    const since = new Date(Date.now() - days * 86_400_000).toISOString();
    const r = await httpGet(
      `${this.BASE}/systems?name=${enc(systemName)}&timeMin=${enc(since)}&count=1`,
      this.TIMEOUT
    );
    const doc = r.body?.docs?.[0];
    if (!doc) return { error: `No history for system: ${systemName}` };

    // Build a simple trend summary per faction
    const trends = (doc.factions || []).map((f) => {
      const history = (f.faction_details?.faction_presence || []).slice(0, days);
      const values = history.map((h) => h.influence).filter((v) => v != null);
      const trend =
        values.length >= 2
          ? ((values[0] - values[values.length - 1]) * 100).toFixed(2)
          : null;
      return {
        faction: f.name,
        currentInfluence:
          values[0] != null ? `${(values[0] * 100).toFixed(2)}%` : 'unknown',
        trendLast7Days: trend != null ? `${trend > 0 ? '+' : ''}${trend}%` : 'insufficient data',
        dataPoints: values.length,
      };
    });

    return {
      source: 'EliteBGS',
      system: doc.name,
      period: `Last ${days} days`,
      trends,
    };
  },
};

// ─── EDSM API (fallback + extras) ────────────────────────────────────────────
// Used when EliteBGS is unavailable, and for sphere searches and traffic data.

const EDSM = {
  BASE_SYS: 'https://www.edsm.net/api-system-v1',
  BASE_V1:  'https://www.edsm.net/api-v1',
  TIMEOUT: 12000,

  async getSystemFactions(systemName) {
    const r = await httpGet(
      `${this.BASE_SYS}/factions?systemName=${enc(systemName)}`,
      this.TIMEOUT
    );
    if (!r.body?.name) return { error: `System not found in EDSM: ${systemName}` };

    const factions = (r.body.factions || [])
      .map((f) => ({
        name: f.name,
        influence: `${(f.influence * 100).toFixed(1)}%`,
        allegiance: f.allegiance,
        government: f.government,
        state: f.state,
        happiness: f.happiness,
        isPlayerFaction: f.isPlayer || false,
        activeStates: (f.activeStates || []).map((s) => s.state),
        pendingStates: (f.pendingStates || []).map((s) => s.state),
        recoveringStates: (f.recoveringStates || []).map((s) => s.state),
      }))
      .sort((a, b) => parseFloat(b.influence) - parseFloat(a.influence));

    return {
      source: 'EDSM',
      system: r.body.name,
      controllingFaction: r.body.controllingFaction?.name || null,
      factions,
    };
  },

  async getSystemInfo(systemName) {
    const r = await httpGet(
      `${this.BASE_V1}/system?systemName=${enc(systemName)}&showInformation=1`,
      this.TIMEOUT
    );
    if (!r.body?.name) return { error: `System not found: ${systemName}` };
    return {
      source: 'EDSM',
      name: r.body.name,
      allegiance: r.body.information?.allegiance,
      government: r.body.information?.government,
      faction: r.body.information?.faction,
      factionState: r.body.information?.factionState,
      population: r.body.information?.population,
      security: r.body.information?.security,
      economy: r.body.information?.economy,
    };
  },

  async getNearbySystems(systemName, radius = 20) {
    const r = Math.min(Number(radius) || 20, 100);
    const data = await httpGet(
      `${this.BASE_V1}/sphere-systems?systemName=${enc(systemName)}&radius=${r}&showInformation=1`,
      this.TIMEOUT
    );
    if (!Array.isArray(data.body)) return { error: `Could not get nearby systems for: ${systemName}` };
    return {
      source: 'EDSM',
      referenceSystem: systemName,
      radiusLY: r,
      count: data.body.length,
      systems: data.body.map((s) => ({
        name: s.name,
        distanceLY: s.distance,
        allegiance: s.information?.allegiance,
        security: s.information?.security,
        population: s.information?.population,
        faction: s.information?.faction,
      })),
    };
  },

  async getFactionPresence(factionName) {
    const data = await httpGet(
      `${this.BASE_V1}/factions?factionName=${enc(factionName)}`,
      this.TIMEOUT
    );
    if (!Array.isArray(data.body) || data.body.length === 0) {
      return { error: `Faction not found in EDSM: ${factionName}` };
    }
    const f = data.body[0];
    return {
      source: 'EDSM',
      name: f.name,
      allegiance: f.allegiance,
      government: f.government,
      isPlayerFaction: f.isPlayer,
      homeSystem: f.homeSystem,
      systemCount: (f.systems || []).length,
      systems: (f.systems || []).map((s) => ({
        name: s.name,
        influence: `${(s.influence * 100).toFixed(1)}%`,
        state: s.state,
        activeStates: (s.activeStates || []).map((st) => st.state),
      })),
    };
  },

  async getSystemTraffic(systemName) {
    const [t, d] = await Promise.all([
      httpGet(`${this.BASE_SYS}/traffic?systemName=${enc(systemName)}`, this.TIMEOUT).catch(() => null),
      httpGet(`${this.BASE_SYS}/deaths?systemName=${enc(systemName)}`, this.TIMEOUT).catch(() => null),
    ]);
    return {
      source: 'EDSM',
      system: systemName,
      totalTraffic: t?.body?.traffic?.total ?? null,
      playerTraffic: t?.body?.traffic?.player ?? null,
      playerDeaths: d?.body?.deaths?.player ?? null,
    };
  },
};

// ─── Smart dual-source wrappers ───────────────────────────────────────────────
// Try EliteBGS first; fall back to EDSM if EliteBGS is down.

async function getSystemFactions(systemName) {
  try {
    return await EliteBGS.getSystemBGS(systemName);
  } catch {
    console.warn(`  [warn] EliteBGS unavailable for "${systemName}", using EDSM fallback`);
    return EDSM.getSystemFactions(systemName);
  }
}

async function getFactionData(factionName) {
  try {
    return await EliteBGS.getFactionBGS(factionName);
  } catch {
    console.warn(`  [warn] EliteBGS unavailable for faction "${factionName}", using EDSM fallback`);
    return EDSM.getFactionPresence(factionName);
  }
}

// ─── Tool dispatch ────────────────────────────────────────────────────────────

const TOOLS = {
  getLatestTick:         (_args) => EliteBGS.getLatestTick(),
  getSystemFactions:     (args)  => getSystemFactions(args.systemName),
  getFactionData:        (args)  => getFactionData(args.factionName),
  getSystemBGSHistory:   (args)  => EliteBGS.getSystemBGSHistory(args.systemName, args.days),
  getSystemInfo:         (args)  => EDSM.getSystemInfo(args.systemName),
  getNearbySystems:      (args)  => EDSM.getNearbySystems(args.systemName, args.radius),
  getSystemTraffic:      (args)  => EDSM.getSystemTraffic(args.systemName),
  getBulkSystemFactions: async (args) => {
    const results = {};
    for (const name of (args.systemNames || [])) {
      results[name] = await getSystemFactions(name).catch((e) => ({ error: e.message }));
    }
    return results;
  },
};

// ─── Gemini tool declarations ──────────────────────────────────────────────────

const toolDeclarations = {
  functionDeclarations: [
    {
      name: 'getLatestTick',
      description:
        'Check when the last BGS tick occurred and whether current data is fresh or stale. ' +
        'Always call this first when doing time-sensitive BGS analysis.',
      parameters: { type: 'OBJECT', properties: {} },
    },
    {
      name: 'getSystemFactions',
      description:
        'Get all factions in a star system with influence %, active BGS states (War, Civil War, ' +
        'Election, Boom, Bust, Expansion, Retreat, etc.), pending and recovering states, happiness, ' +
        'and the controlling faction. Tries EliteBGS first, falls back to EDSM.',
      parameters: {
        type: 'OBJECT',
        properties: {
          systemName: { type: 'STRING', description: 'Exact star system name, e.g. "Sol" or "Deciat"' },
        },
        required: ['systemName'],
      },
    },
    {
      name: 'getFactionData',
      description:
        'Get a faction\'s full presence across all systems: influence in each system, ' +
        'active states, government type, allegiance, home system, and whether it\'s a player faction. ' +
        'Use to track your own faction or monitor a rival across the galaxy.',
      parameters: {
        type: 'OBJECT',
        properties: {
          factionName: { type: 'STRING', description: 'Exact faction name' },
        },
        required: ['factionName'],
      },
    },
    {
      name: 'getSystemBGSHistory',
      description:
        'Get influence trend data for a system over the past N days. ' +
        'Shows whether factions are gaining or losing ground — critical for spotting momentum shifts.',
      parameters: {
        type: 'OBJECT',
        properties: {
          systemName: { type: 'STRING', description: 'Star system name' },
          days: {
            type: 'NUMBER',
            description: 'Number of days of history to retrieve (default 7, max 30)',
          },
        },
        required: ['systemName'],
      },
    },
    {
      name: 'getSystemInfo',
      description:
        'Get general system data from EDSM: population, security level, primary economy, ' +
        'allegiance, government, and controlling faction state.',
      parameters: {
        type: 'OBJECT',
        properties: {
          systemName: { type: 'STRING', description: 'Star system name' },
        },
        required: ['systemName'],
      },
    },
    {
      name: 'getNearbySystems',
      description:
        'Find star systems within a given light-year radius of a reference system via EDSM. ' +
        'Essential for sector analysis, expansion target identification, and regional control mapping.',
      parameters: {
        type: 'OBJECT',
        properties: {
          systemName: { type: 'STRING', description: 'Reference star system name' },
          radius: {
            type: 'NUMBER',
            description: 'Search radius in light years (default 20, max 100)',
          },
        },
        required: ['systemName'],
      },
    },
    {
      name: 'getSystemTraffic',
      description:
        'Get traffic volume and player death counts for a system from EDSM. ' +
        'Useful for gauging how active a system is and whether combat is occurring.',
      parameters: {
        type: 'OBJECT',
        properties: {
          systemName: { type: 'STRING', description: 'Star system name' },
        },
        required: ['systemName'],
      },
    },
    {
      name: 'getBulkSystemFactions',
      description:
        'Fetch faction and BGS data for multiple star systems at once. ' +
        'Use when comparing influence or conflicts across a list of systems simultaneously.',
      parameters: {
        type: 'OBJECT',
        properties: {
          systemNames: {
            type: 'ARRAY',
            items: { type: 'STRING' },
            description: 'List of star system names to analyze',
          },
        },
        required: ['systemNames'],
      },
    },
  ],
};

// ─── Gemini model + agentic loop ──────────────────────────────────────────────

const SYSTEM_INSTRUCTION = `You are an expert Elite Dangerous BGS (Background Simulation) strategist with access to live galaxy data.

DATA SOURCES AVAILABLE:
- EliteBGS: Gold standard for BGS. Provides tick-accurate influence data, historical trends, and state tracking. Use this for all BGS analysis.
- EDSM: Backup source for system info, sector searches, and traffic data.

YOUR WORKFLOW:
1. For time-sensitive analysis, always check getLatestTick first to know if data is fresh.
2. Fetch whatever data you need — chain multiple tool calls if necessary.
3. For multi-system questions, use getBulkSystemFactions to pull everything at once.
4. Always cross-reference faction history (getSystemBGSHistory) when recommending strategy.

BGS EXPERTISE:
- Influence thresholds: Below 5% = retreat risk, above 75% = expansion eligible
- War/Civil War: Both factions locked until one wins combat bonds; recommend focused combat
- Election: Influence-based; recommend trade, exploration, and delivery missions
- Boom: Good time to expand; high mission rewards
- Bust/Famine: Influence is volatile; defend carefully
- Expansion: Faction will move to a new system on next tick
- Retreat: Faction leaving — either help them recover or accelerate the retreat

OUTPUT RULES:
- Always cite exact percentages, system names, and state names from fetched data
- Never invent faction data — if a tool returns an error, say so
- Use bullet points for tactical recommendations
- Flag active Wars and Elections prominently — they are time-critical
- Note the data source (EliteBGS or EDSM) and tick freshness when relevant`;

// Model fallback chain: try each in order until one works
const MODEL_CHAIN = ['gemini-2.5-flash', 'gemini-2.0-flash'];

function createModel(modelName) {
  return genAI.getGenerativeModel({
    model: modelName,
    systemInstruction: SYSTEM_INSTRUCTION,
    tools: [toolDeclarations],
    generationConfig: { maxOutputTokens: 2048, temperature: 0.6 },
  });
}

function isQuotaError(err) {
  return (
    err.message?.includes('429') ||
    err.message?.includes('quota') ||
    err.message?.includes('RESOURCE_EXHAUSTED')
  );
}

// Runs the agentic tool loop for a single chat session
async function runToolLoop(chat, userMessage) {
  let result = await chat.sendMessage(userMessage);

  while (true) {
    const parts = result.response.candidates?.[0]?.content?.parts || [];
    const toolCalls = parts.filter((p) => p.functionCall);

    if (toolCalls.length === 0) {
      return parts.map((p) => p.text || '').join('').trim() || '(No response)';
    }

    const toolResults = await Promise.all(
      toolCalls.map(async (part) => {
        const { name, args } = part.functionCall;
        const fn = TOOLS[name];
        if (!fn) {
          return { functionResponse: { name, response: { error: `Unknown tool: ${name}` } } };
        }
        process.stdout.write(`  [data] ${name}(${JSON.stringify(args)})\n`);
        try {
          const data = await fn(args);
          return { functionResponse: { name, response: data } };
        } catch (err) {
          return { functionResponse: { name, response: { error: err.message } } };
        }
      })
    );

    result = await chat.sendMessage(toolResults);
  }
}

// Wraps runToolLoop with model fallback — if the active model hits quota,
// switches to the next model in MODEL_CHAIN and retries transparently.
async function runWithTools(sessionState, userMessage) {
  while (sessionState.modelIndex < MODEL_CHAIN.length) {
    try {
      return await runToolLoop(sessionState.chat, userMessage);
    } catch (err) {
      if (isQuotaError(err) && sessionState.modelIndex + 1 < MODEL_CHAIN.length) {
        sessionState.modelIndex++;
        const nextModel = MODEL_CHAIN[sessionState.modelIndex];
        console.warn(`\n  [fallback] ${MODEL_CHAIN[sessionState.modelIndex - 1]} quota hit — switching to ${nextModel}\n`);
        // Rebuild chat on the new model, carrying over conversation history
        const model = createModel(nextModel);
        sessionState.chat = model.startChat({ history: sessionState.history.slice() });
        continue;
      }
      throw err;
    }
  }
}

// ─── Tick Timer ───────────────────────────────────────────────────────────────

const TICK_HOUR_UTC   = 15;
const TICK_MINUTE_UTC = 50;
const MONITOR_INTERVAL_MS = 20 * 60 * 1000; // 20 minutes
const MONITOR_DURATION_MS = 60 * 60 * 1000; // 1 hour

function getNextTickUTC() {
  const now = new Date();
  const tick = new Date(Date.UTC(
    now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(),
    TICK_HOUR_UTC, TICK_MINUTE_UTC, 0, 0
  ));
  if (now >= tick) tick.setUTCDate(tick.getUTCDate() + 1);
  return tick;
}

function tickStatus() {
  const now      = new Date();
  const nextTick = getNextTickUTC();
  const msLeft   = nextTick - now;
  const h = Math.floor(msLeft / 3_600_000);
  const m = Math.floor((msLeft % 3_600_000) / 60_000);
  const pad = (n) => String(n).padStart(2, '0');
  return `Next BGS tick: 15:50 UTC  |  T-minus ${pad(h)}h ${pad(m)}m`;
}

// ─── BGS Tick Monitor ─────────────────────────────────────────────────────────

class TickMonitor {
  constructor() {
    this._systems   = [];
    this._baseline  = {};      // systemName -> faction snapshot
    this._intervals = [];
    this._running   = false;
    this._session   = null;
  }

  // Snapshot: { [systemName]: { controllingFaction, factions: [{name,influence,state,activeStates}] } }
  async _snapshot(systemNames) {
    const snap = {};
    for (const name of systemNames) {
      try {
        const d = await getSystemFactions(name);
        snap[name] = {
          controllingFaction: d.controllingFaction || null,
          factions: (d.factions || []).map((f) => ({
            name:         f.name,
            influence:    f.influence,
            state:        f.state,
            activeStates: f.activeStates || [],
          })),
        };
      } catch (e) {
        snap[name] = { error: e.message };
      }
    }
    return snap;
  }

  _detectChanges(before, after) {
    const changes = [];
    for (const sys of Object.keys(after)) {
      const b = before[sys];
      const a = after[sys];
      if (!b || b.error || a.error) continue;

      // Controlling faction changed
      if (b.controllingFaction !== a.controllingFaction) {
        changes.push({
          system: sys,
          type: 'CONTROL_CHANGE',
          from: b.controllingFaction,
          to:   a.controllingFaction,
        });
      }

      // Per-faction influence / state changes
      const bMap = Object.fromEntries((b.factions || []).map((f) => [f.name, f]));
      for (const af of (a.factions || [])) {
        const bf = bMap[af.name];
        if (!bf) {
          changes.push({ system: sys, type: 'FACTION_ENTERED', faction: af.name, influence: af.influence });
          continue;
        }
        const bInf = parseFloat(bf.influence) || 0;
        const aInf = parseFloat(af.influence) || 0;
        const delta = aInf - bInf;
        if (Math.abs(delta) >= 0.1) {
          changes.push({
            system: sys, type: 'INFLUENCE_CHANGE', faction: af.name,
            from: bf.influence, to: af.influence,
            delta: `${delta > 0 ? '+' : ''}${delta.toFixed(2)}%`,
          });
        }
        if (bf.state !== af.state) {
          changes.push({
            system: sys, type: 'STATE_CHANGE', faction: af.name,
            from: bf.state, to: af.state,
          });
        }
        const bStates = new Set(bf.activeStates);
        const aStates = new Set(af.activeStates);
        const entered = [...aStates].filter((s) => !bStates.has(s));
        const exited  = [...bStates].filter((s) => !aStates.has(s));
        if (entered.length) changes.push({ system: sys, type: 'STATE_ENTERED', faction: af.name, states: entered });
        if (exited.length)  changes.push({ system: sys, type: 'STATE_EXITED',  faction: af.name, states: exited });
      }
    }
    return changes;
  }

  async _generateBrief(changes, before, after) {
    const changeText = JSON.stringify(changes, null, 2);
    const afterText  = JSON.stringify(after, null, 2);
    const prompt = `
BGS TICK MONITOR — POST-TICK EXECUTIVE BRIEF REQUEST

The BGS tick has occurred. Here are the detected changes across monitored systems:

CHANGES DETECTED:
${changeText}

CURRENT SYSTEM STATE (post-tick):
${afterText}

Please write a concise EXECUTIVE BRIEF covering:
1. SUMMARY — total systems monitored, how many had changes
2. NOTABLE CHANGES — for each changed system: what changed, from what to what, and why it matters
3. CRITICAL ALERTS — wars, elections, retreats, expansions triggered
4. RECOMMENDED ACTIONS — prioritized tactical steps for the next tick cycle

Format clearly with section headers. Be specific with faction names, percentages, and system names.`;

    try {
      return await runToolLoop(this._session.chat, prompt);
    } catch (e) {
      return `[Brief generation failed: ${e.message}]\n\nRaw changes:\n${changeText}`;
    }
  }

  async start(systemNames, session) {
    if (this._running) {
      console.log('\n  [monitor] Already watching systems. Use /unwatch to stop first.\n');
      return;
    }
    this._systems  = systemNames;
    this._session  = session;
    this._running  = true;

    console.log(`\n${'═'.repeat(65)}`);
    console.log('  *** BGS TICK MONITOR ACTIVATED ***');
    console.log(`  Watching: ${systemNames.join(', ')}`);
    console.log(`  ${tickStatus()}`);
    console.log(`  Polling every 20 min for 1 hour after tick window`);
    console.log(`${'═'.repeat(65)}\n`);

    // Capture baseline
    process.stdout.write('  [monitor] Capturing baseline snapshot...\n');
    this._baseline = await this._snapshot(systemNames);
    process.stdout.write('  [monitor] Baseline captured. Monitoring started.\n\n');

    let pollCount = 0;
    const maxPolls = Math.ceil(MONITOR_DURATION_MS / MONITOR_INTERVAL_MS); // 3 polls

    const poll = async () => {
      if (!this._running) return;
      pollCount++;
      const now = new Date().toISOString().slice(11, 16);
      process.stdout.write(`\n  [monitor] Poll ${pollCount}/${maxPolls} at ${now} UTC — checking systems...\n`);

      const current  = await this._snapshot(this._systems);
      const changes  = this._detectChanges(this._baseline, current);

      if (changes.length > 0) {
        // ALERT
        process.stdout.write('\n');
        console.log('█'.repeat(65));
        console.log('  *** BGS TICK DETECTED — CHANGES FOUND ***');
        console.log(`  ${changes.length} change(s) across monitored systems`);
        console.log('█'.repeat(65));
        process.stdout.write('\n  Generating executive brief...\n');
        const brief = await this._generateBrief(changes, this._baseline, current);
        console.log('\n' + '═'.repeat(65));
        console.log('  EXECUTIVE BRIEF — POST-TICK ANALYSIS');
        console.log('═'.repeat(65));
        console.log(brief);
        console.log('═'.repeat(65) + '\n');
        // Update baseline to current post-tick state
        this._baseline = current;
      } else {
        process.stdout.write('  [monitor] No changes detected yet.\n');
      }

      if (pollCount >= maxPolls) {
        process.stdout.write('\n  [monitor] Monitoring window complete (1 hour elapsed). Use /watch to restart.\n\n');
        this.stop();
      }
    };

    const id = setInterval(poll, MONITOR_INTERVAL_MS);
    this._intervals.push(id);
  }

  stop() {
    this._intervals.forEach((id) => clearInterval(id));
    this._intervals = [];
    this._running   = false;
    this._systems   = [];
    this._baseline  = {};
  }

  get running()  { return this._running; }
  get systems()  { return this._systems; }
}

// ─── CLI ──────────────────────────────────────────────────────────────────────

function banner() {
  console.log(`
  ╔══════════════════════════════════════════════════════════════╗
  ║    Elite Dangerous BGS Analyzer  v5                         ║
  ║    EliteBGS (tick data) + EDSM (sectors) + Gemini (AI)      ║
  ╠══════════════════════════════════════════════════════════════╣
  ║  Ask any BGS question — Gemini fetches live data as needed   ║
  ╠══════════════════════════════════════════════════════════════╣
  ║  Slash commands:                                             ║
  ║   /watch Sol, Deciat, HIP 22460  — monitor after tick        ║
  ║   /unwatch                       — stop monitoring           ║
  ║   /tick                          — show tick countdown       ║
  ╠══════════════════════════════════════════════════════════════╣
  ║  Example questions:                                          ║
  ║   • "Is the tick fresh? Check Deciat's BGS state"            ║
  ║   • "Any factions at war near Sol within 20ly?"              ║
  ║   • "Show influence trends in HIP 22460 over 7 days"         ║
  ║   • "Track the faction [name] across all their systems"      ║
  ║   • "Which factions in Pleiades are close to retreating?"    ║
  ╠══════════════════════════════════════════════════════════════╣
  ║  Type  exit  to quit                                         ║
  ╚══════════════════════════════════════════════════════════════╝
`);
}

async function main() {
  banner();

  const rl      = readline.createInterface({ input: process.stdin, output: process.stdout });
  const prompt  = (q) => new Promise((res) => rl.question(q, res));
  const monitor = new TickMonitor();

  // Session state: tracks active model index, chat instance, and history
  const session = {
    modelIndex: 0,
    history: [],
    chat: createModel(MODEL_CHAIN[0]).startChat({ history: [] }),
  };

  console.log(`  Active model: ${MODEL_CHAIN[0]} (fallback: ${MODEL_CHAIN.slice(1).join(' → ')})`);
  console.log(`  ${tickStatus()}\n`);

  // Auto-start monitoring if WATCH_SYSTEMS is set in .env
  // e.g. WATCH_SYSTEMS=Sol,Deciat,HIP 22460
  const autoSystems = (process.env.WATCH_SYSTEMS || '')
    .split(',').map((s) => s.trim()).filter(Boolean);
  if (autoSystems.length > 0) {
    setImmediate(() => monitor.start(autoSystems, session));
  }

  while (true) {
    const input = (await prompt('\nBGS > ')).trim();
    if (!input) continue;

    // ── Slash commands ─────────────────────────────────────────
    if (input.toLowerCase() === 'exit' || input.toLowerCase() === 'quit') {
      monitor.stop();
      console.log('\n  Fly safe, CMDR o7\n');
      rl.close();
      break;
    }

    if (input.toLowerCase() === '/tick') {
      console.log(`\n  ${tickStatus()}\n`);
      continue;
    }

    if (input.toLowerCase().startsWith('/watch')) {
      const arg = input.slice('/watch'.length).trim();
      if (!arg) {
        console.log('\n  Usage: /watch SystemA, SystemB, SystemC\n');
        continue;
      }
      const systems = arg.split(',').map((s) => s.trim()).filter(Boolean);
      await monitor.start(systems, session);
      continue;
    }

    if (input.toLowerCase() === '/unwatch') {
      if (monitor.running) {
        monitor.stop();
        console.log('\n  [monitor] Monitoring stopped.\n');
      } else {
        console.log('\n  [monitor] No active monitoring session.\n');
      }
      continue;
    }

    // ── Normal AI query ────────────────────────────────────────
    console.log('');
    try {
      const answer = await runWithTools(session, input);
      // Keep a copy of history for model rebuilds on fallback
      session.history.push({ role: 'user', parts: [{ text: input }] });
      session.history.push({ role: 'model', parts: [{ text: answer }] });

      console.log('\n' + '─'.repeat(65));
      console.log(answer);
      console.log('─'.repeat(65) + '\n');
    } catch (err) {
      if (isQuotaError(err)) {
        console.error(
          '\n  All models exhausted their free-tier quota for today.\n' +
          '  Quotas reset daily. You can also get a fresh key at aistudio.google.com\n'
        );
      } else {
        console.error(`\n  Error: ${err.message}\n`);
      }
    }
  }
}

main().catch((err) => {
  console.error('\nFatal:', err.message);
  process.exit(1);
});
