/**
 * Inara API client — Ken'Tarii Mandate Intelligence
 *
 * Docs / key registration: https://inara.cz/elite/settings-api/
 * API endpoint:            https://inara.cz/inapi/v1/
 */

const https = require('https');

const ENDPOINT   = 'https://inara.cz/inapi/v1/';
const APP_NAME   = 'KenTariiMandateMonitor';
const APP_VER    = '1.0';
const TIMEOUT_MS = 15000;

// ─── Core POST helper ─────────────────────────────────────────────────────────

function inaraPost(apiKey, events) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      header: {
        appName:     APP_NAME,
        appVersion:  APP_VER,
        isDeveloped: true,
        APIkey:      apiKey,
      },
      events,
    });

    const req = https.request(
      {
        hostname: 'inara.cz',
        path:     '/inapi/v1/',
        method:   'POST',
        headers: {
          'Content-Type':   'application/json',
          'Content-Length': Buffer.byteLength(body),
          'User-Agent':     `${APP_NAME}/${APP_VER}`,
        },
      },
      (res) => {
        let raw = '';
        res.on('data', (c) => (raw += c));
        res.on('end', () => {
          try {
            resolve(JSON.parse(raw));
          } catch {
            reject(new Error(`Inara returned non-JSON (HTTP ${res.statusCode})`));
          }
        });
      }
    );

    req.setTimeout(TIMEOUT_MS, () => {
      req.destroy();
      reject(new Error('Inara API request timed out'));
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function ev(eventName, eventData) {
  return { eventName, eventTimestamp: new Date().toISOString(), eventData };
}

function checkEvent(result, idx = 0) {
  const event = result?.events?.[idx];
  if (!event) throw new Error('Empty response from Inara');
  if (event.eventStatus !== 200) {
    throw new Error(`Inara error ${event.eventStatus}: ${event.eventStatusText || 'unknown'}`);
  }
  return event.eventData;
}

// ─── Public API methods ───────────────────────────────────────────────────────

/**
 * Get squadron info by name.
 * Returns: name, tag, allegiance, power, inaraURL, memberCount, etc.
 */
async function getSquadron(apiKey, squadronName) {
  const result = await inaraPost(apiKey, [ev('getSquadron', { squadronName })]);
  return checkEvent(result);
}

/**
 * Look up a CMDR profile by name.
 * Returns: preferredGameRole, ranks, ship, squadron membership, etc.
 */
async function getCmdr(apiKey, cmdrName) {
  const result = await inaraPost(apiKey, [ev('getCmdr', { searchName: cmdrName })]);
  return checkEvent(result);
}

/**
 * Batch: fetch squadron + a CMDR in one round-trip.
 */
async function getSquadronAndCmdr(apiKey, squadronName, cmdrName) {
  const events = [ev('getSquadron', { squadronName })];
  if (cmdrName) events.push(ev('getCmdr', { searchName: cmdrName }));
  const result = await inaraPost(apiKey, events);

  return {
    squadron: cmdrName ? checkEvent(result, 0) : checkEvent(result),
    cmdr:     cmdrName ? (() => { try { return checkEvent(result, 1); } catch { return null; } })() : null,
  };
}

module.exports = { getSquadron, getCmdr, getSquadronAndCmdr };
