@echo off
title BGS Intelligence Dashboard - Setup
color 0B
echo.
echo  ============================================
echo   BGS Intelligence Dashboard
echo   First-Time Setup
echo  ============================================
echo.

cd /d "%~dp0"

REM ── Step 1: Node.js ───────────────────────────────────────────────────────────
echo [1/5] Checking Node.js...
where node >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [ERROR] Node.js is NOT installed.
  echo.
  echo  Please install it manually:
  echo    1. Go to: https://nodejs.org/en/download
  echo    2. Download the LTS version for Windows
  echo    3. Run the installer (keep all defaults)
  echo    4. Re-run this setup.bat after installing
  echo.
  pause
  exit /b 1
)
for /f "tokens=*" %%v in ('node --version') do echo  [OK] Node.js %%v found

REM ── Step 2: npm dependencies ──────────────────────────────────────────────────
echo.
echo [2/5] Installing npm packages (may take 1-2 minutes)...
npm install
if errorlevel 1 (
  echo.
  echo  [ERROR] npm install failed. Check your internet connection and try again.
  pause
  exit /b 1
)
echo  [OK] All packages installed

REM ── Step 3: data directory ────────────────────────────────────────────────────
echo.
echo [3/5] Creating data directory...
if not exist "%~dp0data" mkdir "%~dp0data"
echo  [OK] data\ directory ready

REM ── Step 4: ngrok ─────────────────────────────────────────────────────────────
echo.
echo [4/5] Checking ngrok...
where ngrok >nul 2>&1
if errorlevel 1 (
  echo  ngrok not found. Attempting to install via winget...
  winget install --id Ngrok.Ngrok --accept-package-agreements --accept-source-agreements
  if errorlevel 1 (
    echo.
    echo  [WARN] Could not auto-install ngrok.
    echo         Download it manually from: https://ngrok.com/download
    echo         Extract ngrok.exe to this folder or add it to your PATH.
    echo         Then run: ngrok config add-authtoken YOUR_TOKEN
    echo.
  ) else (
    echo  [OK] ngrok installed
    echo.
    echo  [ACTION NEEDED] Add your ngrok authtoken:
    echo    1. Sign up / log in at: https://dashboard.ngrok.com
    echo    2. Copy your authtoken from: https://dashboard.ngrok.com/get-started/your-authtoken
    echo    3. Run this command:  ngrok config add-authtoken PASTE_TOKEN_HERE
    echo.
    pause
  )
) else (
  echo  [OK] ngrok already installed
)

REM ── Step 5: .env configuration ────────────────────────────────────────────────
echo.
echo [5/5] Configuring environment...
if not exist "%~dp0.env" (
  echo  Creating .env from template...
  copy "%~dp0.env.example" "%~dp0.env" >nul
  echo  [OK] .env created
  echo.
  echo  ================================================================
  echo   NOTE: API keys can be configured through the setup wizard
  echo   that appears on first launch in your browser.
  echo   Alternatively, edit .env directly in Notepad.
  echo   Get a free Gemini key at: https://aistudio.google.com/
  echo  ================================================================
  echo.
  timeout /t 3 /nobreak > nul
) else (
  echo  [OK] .env already exists
)

REM ── Done ──────────────────────────────────────────────────────────────────────
echo.
echo  ============================================
echo   Setup complete!
echo  ============================================
echo.
echo   To launch the dashboard:
echo     Double-click  start.bat
echo.
echo   The setup wizard will open in your browser on first launch.
echo   Enter your squadron name and API keys there.
echo.
echo   Local URL:
echo     http://localhost:3000
echo.
pause
